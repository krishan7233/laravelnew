
<?php $__env->startSection('content'); ?>
<div class="container-fluid">
 <div class="row">
<div class="col-lg-12">
    <?php if(session()->has('success')): ?>
   <div class="alert alert-success">
    <?php if(is_array(session()->get('success'))): ?>
            <ul>
                <?php $__currentLoopData = session()->get('success'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($message); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
            <?php else: ?>
                <?php echo e(session()->get('success')); ?>

            <?php endif; ?>
        </div>
    <?php endif; ?>
     <?php if(count($errors) > 0): ?>
      <?php if($errors->any()): ?>
        <div class="alert alert-danger" role="alert">
          <?php echo e($errors->first()); ?>

          <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">×</span>
          </button>
        </div>
      <?php endif; ?>
    <?php endif; ?>
</div>
<div class="col-lg-12">
<div class="card">    
<div class="card-header card-header-primary">
      <h4 class="card-title "><?php echo e(__('keywords.Missed Orders')); ?></h4>
    </div>
<div class="container"> <br> 
<table id="datatableDefault" class="table text-nowrap w-100">
    <thead class="thead-light">
        <tr>
            <th class="text-center">#</th>
            <th><?php echo e(__('keywords.Cart_id')); ?></th>
             <th><?php echo e(__('keywords.Store')); ?></th>
              <th><?php echo e(__('keywords.Total Price')); ?></th>
             <th><?php echo e(__('keywords.Paid By Wallet')); ?></th>
             <th><?php echo e(__('keywords.Delivery Charge')); ?></th>
             <th><?php echo e(__('keywords.Coupon Discount')); ?></th>
            <th><?php echo e(__('keywords.Remaining Price')); ?></th>
            <th><?php echo e(__('keywords.User')); ?></th>
            <th><?php echo e(__('keywords.Delivery_Date')); ?></th>
            <th><?php echo e(__('keywords.Cart Products')); ?></th>
            <th><?php echo e(__('keywords.Assign')); ?></th>
            <th><?php echo e(__('keywords.Order Status')); ?></th>
        </tr>
    </thead>
    <tbody>
           <?php if(count($ord)>0): ?>
          <?php $i=1; ?>
          <?php $__currentLoopData = $ord; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ords): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td class="text-center"><?php echo e($i); ?></td>
            <td><?php echo e($ords->cart_id); ?></td>
            <td><?php echo e($ords->store_name); ?><p style="font-size:14px">(<?php echo e($ords->phone_number); ?>)</p></td>
            <td><?php echo e($ords->total_price); ?></td>
            <td><?php echo e($ords->paid_by_wallet); ?></td>
            <td><?php echo e($ords->delivery_charge); ?></td>
            <td><?php echo e($ords->coupon_discount); ?></td>
            <td><?php echo e($ords->rem_price); ?></td>
            <td><?php echo e($ords->name); ?><p style="font-size:14px">(<?php echo e($ords->user_phone); ?>)</p></td>
             <td><?php echo e($ords->delivery_date); ?>(<?php echo e($ords->time_slot); ?>)</td>
            <td><button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModal1<?php echo e($ords->cart_id); ?>">Details</button></td>
            <td><button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModal1<?php echo e($ords->order_id); ?>"><?php if($ords->boy_name != NULL): ?><?php echo e(__('keywords.Assigned')); ?>(<?php echo e($ords->boy_name); ?>)<?php else: ?><?php echo e(__('keywords.Assigned')); ?><?php endif; ?></button><br>
            </td>
            <td><a href="<?php echo e(route('changeStatus', $ords->cart_id)); ?>" class="btn btn-primary">Cancel/Refund</a></td>
        </tr>
          <?php $i++; ?>
                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  <?php else: ?>
                    <tr>
                      <td><?php echo e(__('keywords.No data found')); ?></td>
                    </tr>
                  <?php endif; ?>
    </tbody>
</table>
</div>
</div>
</div>
</div>
</div>
<div>
</div>


<!--/////////details model//////////-->
<?php $__currentLoopData = $ord; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ords): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="modal fade" id="exampleModal1<?php echo e($ords->cart_id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        	<div class="modal-dialog" role="document">
        		<div class="modal-content">
        			<div class="modal-header">
        				<h5 class="modal-title" id="exampleModalLabel"><?php echo e(__('keywords.Order Details')); ?> (<b><?php echo e($ords->cart_id); ?></b>)</h5>
        					<button type="button" class="close" data-dismiss="modal" aria-label="Close">
        						<span aria-hidden="true">&times;</span>
        					</button>
        			</div>
        			<!--//form-->
        			<table class="table table-bordered" id="example2" width="100%" cellspacing="0">
                      <thead>
                        <tr>
                        <th><?php echo e(__('keywords.product details')); ?></th>
                        <th><?php echo e(__('keywords.order qty')); ?></th>
                        <th><?php echo e(__('keywords.Price')); ?></th>
                        </tr>
                      </thead>
                      
                      <tbody>
                      <?php if(count($details)>0): ?>
                                      <?php $i=1; ?>
                                      
                          <tr>             
                        <?php $__currentLoopData = $details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detailss): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <?php if($detailss->cart_id==$ords->cart_id): ?>
                            <td><p><img style="width:25px;height:25px; border-radius:50%" src="<?php echo e(url($detailss->varient_image)); ?>" alt="$detailss->product_name">  <?php echo e($detailss->product_name); ?>(<?php echo e($detailss->quantity); ?><?php echo e($detailss->unit); ?>)</p>
                            </td>
                            <td><?php echo e($detailss->qty); ?></td>
                            <td> 
                            <p><span style="color:grey"><?php echo e($detailss->price); ?></span></p>
                           </td>
    		          	  <?php endif; ?>
                         </tr>
                            <?php $i++; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          <?php else: ?>
                            <tr>
                              <td><?php echo e(__('keywords.No data found')); ?></td>
                            </tr>
                                  <?php endif; ?>
                                   
                      </tbody>
                    </table>

        			<!--//form-->
        		</div>
        	</div>
        </div>
 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
 
 <?php $__currentLoopData = $ord; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ords): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="modal fade" id="exampleModal1<?php echo e($ords->order_id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        	<div class="modal-dialog" role="document">
        		<div class="modal-content">
        			<div class="modal-header">
        				<h5 class="modal-title" id="exampleModalLabel"><?php echo e(__('keywords.Assign')); ?> (<b><?php echo e($ords->cart_id); ?></b>)</h5>
        					<button type="button" class="close" data-dismiss="modal" aria-label="Close">
        						<span aria-hidden="true">&times;</span>
        					</button>
        			</div>
        			<!--//form-->
        			<form class="forms-sample" action="<?php echo e(route('ad_dboy_assign', $ords->cart_id)); ?>" method="post" enctype="multipart/form-data">
                      <?php echo e(csrf_field()); ?>

        			<div class="row">
        			  <div class="col-md-3" align="center"></div>  
                      <div class="col-md-6" align="center">
                        <div class="form-group">
        		     	<select name="d_boy" class="form-control">
        			    <option disabled selected><?php echo e(__('keywords.Select Delivery Boy')); ?></option>
        			    <?php $__currentLoopData = $delivery; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $boys): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        			    <?php if($ords->store_id ==$boys->store_id): ?>
        			    <option value="<?php echo e($boys->ad_dboy_id); ?>"><?php echo e($boys->boy_name); ?></option>
        			    <?php endif; ?>
        			    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        			</select>
        			</div>
        			<button type="submit" class="btn btn-primary pull-center"><?php echo e(__('keywords.Submit')); ?></button>
        			</div>
        			</div>
        			  
                    <div class="clearfix"></div>
        			</form>
        			<!--//form-->
        		</div>
        	</div>
        </div>
 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <?php $__env->stopSection(); ?>
</div>
<?php echo $__env->make('admin.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/softgentech/projectfiles.softgentech.com/projectfiles/source/resources/views/admin/all_orders/missed.blade.php ENDPATH**/ ?>