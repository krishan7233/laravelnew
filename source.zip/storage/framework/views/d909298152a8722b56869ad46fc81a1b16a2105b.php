 <link href="https://fonts.googleapis.com/css?family=Nunito:200,600" rel="stylesheet">
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/switchery/0.8.2/switchery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>
<style>
/* The container */
.radicont {
  display: block;
  position: relative;
  padding-left: 35px;
  margin-bottom: 12px;
  cursor: pointer;
  font-size: 22px;
  -webkit-user-select: none;
  -moz-user-select: none;
  -ms-user-select: none;
  user-select: none;
}

/* Hide the browser's default radio button */
.radicont input {
  position: absolute;
  opacity: 0;
  cursor: pointer;
}

/* Create a custom radio button */
.radio {
  position: absolute;
  top: 0;
  left: 0;
  height: 25px;
  width: 25px;
  background-color: #eee;
  border-radius: 50%;
}

/* On mouse-over, add a grey background color */
.radicont:hover input ~ .radio {
  background-color: #ccc;
}

/* When the radio button is checked, add a blue background */
.radicont input:checked ~ .radio {
  background-color: #2196F3;
}

/* Create the indicator (the dot/circle - hidden when not checked) */
.radio:after {
  content: "";
  position: absolute;
  display: none;
}

/* Show the indicator (dot/circle) when checked */
.radicont input:checked ~ .radio:after {
  display: block;
}

/* Style the indicator (dot/circle) */
.radicont .radio:after {
  top: 9px;
  left: 9px;
  width: 8px;
  height: 8px;
  border-radius: 50%;
  background: white;
}
</style>
<?php $__env->startSection('content'); ?>
<br>

<!-- BEGIN container -->
      <div class="container">
        <!-- BEGIN row -->
        <div class="row justify-content-center">
          <!-- BEGIN col-10 -->
          <div class="col-xl-10">
            <!-- BEGIN row -->
            <div class="row">
              <!-- BEGIN col-9 -->
              <div class="col-xl-9">
                  <?php if(session()->has('success')): ?>
               <div class="alert alert-success">
                <?php if(is_array(session()->get('success'))): ?>
                        <ul>
                            <?php $__currentLoopData = session()->get('success'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($message); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                        <?php else: ?>
                            <?php echo e(session()->get('success')); ?>

                        <?php endif; ?>
                    </div>
                <?php endif; ?>
                 <?php if(count($errors) > 0): ?>
                  <?php if($errors->any()): ?>
                    <div class="alert alert-danger" role="alert">
                      <?php echo e($errors->first()); ?>

                      <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">×</span>
                      </button>
                    </div>
                  <?php endif; ?>
                <?php endif; ?>
                <!-- BEGIN #general -->
                <div id="general" class="mb-5">
                  <h4><i class="far fa-user fa-fw"></i> <?php echo e(__('keywords.Global Settings')); ?></h4>
                  <p><?php echo e(__('keywords.View and update your Global settings')); ?>.</p>
              
                  
                         <div class="card">
                                        <div class="card-header card-header-primary">
                                          <h4 class="card-title"><?php echo e(__('keywords.App Name')); ?> | <?php echo e(__('keywords.Site Logo')); ?> | <?php echo e(__('keywords.Favicon')); ?> | <?php echo e(__('keywords.Country Code')); ?></h4>
                                          <form class="forms-sample" action="<?php echo e(route('updateappdetails')); ?>" method="post" enctype="multipart/form-data">
                                              <?php echo e(csrf_field()); ?>

                                        </div>
                                        <div class="card-body">
                         
                                             <div class="row">
                                              <div class="col-md-6">
                                                <div class="form-group">
                                                  <label class="bmd-label-floating"><?php echo e(__('keywords.App Name')); ?></label>
                                                  <input type="text"name="app_name" value="<?php echo e(($logo->name)); ?>" class="form-control">
                                                </div>
                                              </div>
                                               <div class="col-md-6">
                                                <div class="form-group">
                                                  <label class="bmd-label-floating"><?php echo e(__('keywords.Country Code')); ?></label>
                                                  <input type="text"name="country_code" value="<?php echo e(($cc->country_code)); ?>" class="form-control">
                                                </div>
                                              </div>
                        
                                            </div>
                                             <div class="row">
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                  <label class="bmd-label-floating"><?php echo e(__('keywords.Phone Number Length')); ?></label>
                                                  <input type="text"name="number_length" value="<?php echo e(($logo->number_limit)); ?>" class="form-control">
                                                </div>
                                              </div>
                                              
                                              <div class="col-md-6">
                                                <div class="form-group">
                                                  <label class="bmd-label-floating"><?php echo e(__('keywords.Last Location in App')); ?></label>
                                                  <select name="last_loc" class="form-control">
                                                      <option value="1" <?php if($logo->last_loc==1): ?> selected <?php endif; ?>><?php echo e(__('keywords.Save')); ?></option>
                                                      <option value="0" <?php if($logo->last_loc==0): ?> selected <?php endif; ?>><?php echo e(__('keywords.Do Not Save')); ?></option>
                                                  </select>
                                                </div>
                                              </div>
                                              </div>
                                            <div class="row">
                                              <div class="col-md-6">
                                               
                                             <img src="<?php echo e($url_aws.$logo->icon); ?>" alt="app logo" class="rounded-circle" style="width:100px; height:100px;">
                                               <div class="custom-file">
                                                  <input type="file" name="app_icon" class="custom-file-input" id="customFile" accept="image/*"/>
                                                  <label class="custom-file-label" for="customFile"><?php echo e(__('keywords.Site Logo')); ?></label>
                                                </div>
                                              </div>
                        
                        
                                             <div class="col-md-6">
                                             <img src="<?php echo e($url_aws.$logo->favicon); ?>" alt="app logo" class="rounded-circle" style="width:100px; height:100px;">
                                               <div class="custom-file">
                                                  <input type="file" name="favicon" class="custom-file-input" id="customFile" accept="image/*"/>
                                                  <label class="custom-file-label" for="customFile"><?php echo e(__('keywords.Favicon')); ?></label>
                                                </div>
                                              </div>
                        
                                            </div>
                                            <br>
                                             <div class="form-group row">
                                                <div class="col-sm-10">
                                                  <button type="submit" class="btn btn-primary"><?php echo e(__('keywords.Submit')); ?></button>
                                                </div>
                                              </div>
                                            <div class="clearfix"></div>
                                          </form>
                                        </div>
                                      </div><hr>
                                    
                                        <div class="card">
                                        <div class="card-header card-header-primary">
                                          <h4 class="card-title"><?php echo e(__('keywords.Currency')); ?></h4>
                                          <form class="forms-sample" action="<?php echo e(route('updatecurrency')); ?>" method="post" enctype="multipart/form-data">
                                              <?php echo e(csrf_field()); ?>

                                        </div>
                                        <div class="card-body">
                         
                                             <div class="row">
                                              <div class="col-md-6">
                                                <div class="form-group">
                                                  <label class="bmd-label-floating"><?php echo e(__('keywords.Currency Name')); ?></label>
                                                  
                                                  <select class="form-control select2 auto-select" name="currency_name" id="currency_name" required>
                        <option value="USD" <?php if($currency->currency_name == "USD"): ?>selected <?php endif; ?>><?php echo e(__('keywords.U.S. Dollar')); ?></option>
                        <option value="AUD"<?php if($currency->currency_name == "AUD"): ?>selected <?php endif; ?>><?php echo e(__('keywords.Australian Dollar')); ?></option>
                        <option value="BRL"<?php if($currency->currency_name == "BRL"): ?>selected <?php endif; ?>><?php echo e(__('keywords.Brazilian Real')); ?></option>
                        <option value="CAD"<?php if($currency->currency_name == "CAD"): ?>selected <?php endif; ?>><?php echo e(__('keywords.Canadian Dollar')); ?></option>
                        <option value="CZK"<?php if($currency->currency_name == "CZK"): ?>selected <?php endif; ?>><?php echo e(__('keywords.Czech Koruna')); ?></option>
                        <option value="DKK"<?php if($currency->currency_name == "DKK"): ?>selected <?php endif; ?>><?php echo e(__('keywords.Danish Krone')); ?></option>
                        <option value="EUR"<?php if($currency->currency_name == "EUR"): ?>selected <?php endif; ?>><?php echo e(__('keywords.Euro')); ?></option>
                        <option value="HKD"<?php if($currency->currency_name == "HKD"): ?>selected <?php endif; ?>><?php echo e(__('keywords.Hong Kong Dollar')); ?></option>
                        <option value="HUF"<?php if($currency->currency_name == "HUF"): ?>selected <?php endif; ?>><?php echo e(__('keywords.Hungarian Forint')); ?></option>
                        <option value="INR"<?php if($currency->currency_name == "INR"): ?>selected <?php endif; ?>><?php echo e(__('keywords.Indian Rupee')); ?>(<?php echo e(__('keywords.For Razorpay')); ?>)</option>
                        <option value="ILS"<?php if($currency->currency_name == "ILS"): ?>selected <?php endif; ?>><?php echo e(__('keywords.Israeli New Sheqel')); ?></option>
                        <option value="JPY"<?php if($currency->currency_name == "JPY"): ?>selected <?php endif; ?>><?php echo e(__('keywords.Japanese Yen')); ?></option>
                        <option value="MYR"<?php if($currency->currency_name == "MYR"): ?>selected <?php endif; ?>><?php echo e(__('keywords.Malaysian Ringgit')); ?></option>
                        <option value="MXN"<?php if($currency->currency_name == "MXN"): ?>selected <?php endif; ?>><?php echo e(__('keywords.Mexican Peso')); ?></option>
                        <option value="NOK"<?php if($currency->currency_name == "NOK"): ?>selected <?php endif; ?>><?php echo e(__('keywords.Norwegian Krone')); ?></option>
                        <option value="NZD"<?php if($currency->currency_name == "NZD"): ?>selected <?php endif; ?>><?php echo e(__('keywords.New Zealand Dollar')); ?></option>
                        <option value="PHP"<?php if($currency->currency_name == "PHP"): ?>selected <?php endif; ?>><?php echo e(__('keywords.Philippine Peso')); ?></option>
                        <option value="PLN"<?php if($currency->currency_name == "PLN"): ?>selected <?php endif; ?>><?php echo e(__('keywords.Polish Zloty')); ?></option>
                        <option value="GBP"<?php if($currency->currency_name == "GBP"): ?>selected <?php endif; ?>><?php echo e(__('keywords.Pound Sterling')); ?></option>
                        <option value="SGD"<?php if($currency->currency_name == "SGD"): ?>selected <?php endif; ?>><?php echo e(__('keywords.Singapore Dollar')); ?></option>
                        <option value="SEK"<?php if($currency->currency_name == "SEK"): ?>selected <?php endif; ?>><?php echo e(__('keywords.Swedish Krona')); ?></option>
                        <option value="CHF"<?php if($currency->currency_name == "CHF"): ?>selected <?php endif; ?>><?php echo e(__('keywords.Swiss Franc')); ?></option>
                        <option value="TWD"<?php if($currency->currency_name == "TWD"): ?>selected <?php endif; ?>><?php echo e(__('keywords.Taiwan New Dollar')); ?></option>
                        <option value="THB"<?php if($currency->currency_name == "THB"): ?>selected <?php endif; ?>><?php echo e(__('keywords.Thai Baht')); ?></option>
                        <option value="TRY"<?php if($currency->currency_name == "TRY"): ?>selected <?php endif; ?>><?php echo e(__('keywords.Turkish Lira')); ?></option>
                      
                        <option value="GHS" <?php if($currency->currency_name == "GHS"): ?>selected <?php endif; ?>><?php echo e(__('keywords.Ghana')); ?>  (<?php echo e(__('keywords.For Paystack')); ?>)</option>
                        <option value="NGN" <?php if($currency->currency_name == "NGN"): ?>selected <?php endif; ?>><?php echo e(__('keywords.Nigeria')); ?>(<?php echo e(__('keywords.For Paystack')); ?>)</option>
                        <option value="ZAR" <?php if($currency->currency_name == "ZAR"): ?>selected <?php endif; ?>><?php echo e(__('keywords.South Africa')); ?>(<?php echo e(__('keywords.For Paystack')); ?>)</option>
                      </select>
                                                  
                                                </div>
                                              </div>
                                               <div class="col-md-6">
                                                <div class="form-group">
                                                  <label class="bmd-label-floating"><?php echo e(__('keywords.Currency Sign')); ?></label>
                                                  <input type="text" name="currency_sign" value="<?php echo e(($currency->currency_sign)); ?>" class="form-control">
                                                </div>
                                              </div>
                        
                                            </div>
                                              <div class="form-group row">
                                                <div class="col-sm-10">
                                                  <button type="submit" class="btn btn-primary"><?php echo e(__('keywords.SUBMIT')); ?></button>
                                                </div>
                                              </div>
                                            <div class="clearfix"></div>
                                          </form>
                                        </div>
                                      </div><hr>
                                    
                                        <div class="card">
                                        <div class="card-header card-header-primary">
                                          <h4 class="card-title"><?php echo e(__('keywords.Referral Points')); ?></h4>
                                          <form class="forms-sample" action="<?php echo e(route('updateref')); ?>" method="post" enctype="multipart/form-data">
                                              <?php echo e(csrf_field()); ?>

                                        </div>
                                         <?php
                                        $offer = json_decode($referral->points);
                                      ?>
                                        <div class="card-body">
                                  
                                             <div class="row">
                                              <div class="form-group col-12">
                                              <label for="scratch_card_name"><?php echo e(__('keywords.Referral For')); ?> :</label>
                                              <input type="text" class="form-control" id="name" name="name" <?php if($referral): ?> value="<?php echo e($referral->name); ?>" <?php endif; ?> readonly>
                                            </div>
                                              <div class="col-6" >
                                                <div class="form-group">
                                                  <label for="min_amount"><?php echo e(__('keywords.min amount')); ?> :</label>
                                                  <input type="text" class="form-control" id="min_amount" name="min_amount" placeholder="min amount" <?php if($referral): ?> value="<?php echo e($offer->min); ?>" <?php endif; ?> required>
                                                </div>
                                              </div>
                                                  <div class="col-6" >

                                                <div class="form-group">
                                                  <label for="max_amount"><?php echo e(__('keywords.max amount')); ?> :</label>
                                                  <input type="text" class="form-control" id="max_amount" name="max_amount" placeholder="max amount" <?php if($referral): ?> value="<?php echo e($offer->max); ?>"<?php endif; ?> required>
                                                </div>
                                              </div>

                        
                                            </div>
                                              <div class="form-group row">
                                                <div class="col-sm-10">
                                                  <button type="submit" class="btn btn-primary"><?php echo e(__('keywords.SUBMIT')); ?></button>
                                                </div>
                                              </div>
                                            <div class="clearfix"></div>
                                          </form>
                                        </div>
                                      </div>
                
                
                       <?php if(count($usernull)>0 && count($usernull1)>0): ?>

                           <div class="card">
                                    <div class="card-header card-header-primary">
                                      <h4 class="card-title"><?php echo e(__('keywords.Generate Referral Codes')); ?></h4>
                                      <p><?php echo e(__('keywords.Generate Referral Codes For The Users Who Does Not Have Referral Codes')); ?></p>
                                        <a href=<?php echo e(route('updatereferral_codes')); ?> class="btn btn-primary pull-center"><?php echo e(__('keywords.Generate Referral Codes')); ?></a>
                                     </div>
                            </div>
                      <?php endif; ?>
                  
                </div>
                <!-- END #general -->
                
                <!-- BEGIN #notifications -->
                <div id="sms" class="mb-5">
                  <h4><i class="far fa-bell fa-fw"></i> <?php echo e(__('keywords.OTP and SMS')); ?></h4>
                  <p><?php echo e(__('keywords.SMS and OTP settings')); ?></p>
                  <div class="card">
                      <div class="card-header card-header-primary">
                                          <h4 class="card-title"><?php echo e(__('keywords.SMS from')); ?></h4>
                                        </div>
                    <div class="list-group list-group-flush">
                      <div class="list-group-item d-flex align-items-center">
                        <div class="flex-fill">
                          <div><?php echo e(__('keywords.SMS Gateway')); ?></div>
                          <div class="text-gray-700 d-flex align-items-center">
                            <i class="fa fa-circle fs-8px fa-fw text-success mr-1"></i> <?php if($smsby->status == 0 && $smsby->twilio == 0 && $smsby->msg91 == 0): ?> <?php echo e(__('keywords.OTP/SMS OFF')); ?> &nbsp;<span style="height: 12px;width: 12px;background-color: red;border-radius: 50%;display: inline-block;" class="dot"></span> <?php endif; ?>
                                                          <?php if($smsby->status == 1 && $smsby->twilio == 1 && $smsby->msg91 == 0): ?>  <?php echo e(__('keywords.Twilio is On')); ?> &nbsp;<span style="height: 12px;width: 12px;background-color: green;border-radius: 50%;display: inline-block;" class="dot"></span> <?php endif; ?> 
                                                          <?php if($smsby->status == 1 && $smsby->twilio == 0 && $smsby->msg91 == 1): ?>  <?php echo e(__('keywords.Msg91 is On')); ?> &nbsp;<span style="height: 12px;width: 12px;background-color: green;border-radius: 50%;display: inline-block;" class="dot"></span> <?php endif; ?>
                          </div>
                        </div>
                        <div>
                          <a href="#modalEditsms" data-toggle="modal" class="btn btn-default width-100"><?php echo e(__('keywords.Edit')); ?></a>
                        </div>
                      </div>
                    <hr>
                      
                                             <div class="card">
                                            <div class="card-header card-header-primary">
                                              <h4 class="card-title"><?php echo e(__('keywords.Firebase for OTP')); ?></h4>
                                            </div>
                                            <div class="card-body">
                             
                                                 <div class="row">
                                                 <div class="col-md-12">
                                                <label><?php echo e(__('keywords.Firebase for OTP')); ?> : &nbsp;</label> 
                                                <div class="custom-control custom-switch">
                                                  <input type="checkbox" class="custom-control-input customSwitch1" id="customSwitch1" name="status" <?php echo e($firebase->status == 1 ? 'checked' : ''); ?>>
                                                  <label class="custom-control-label" for="customSwitch1"><?php echo e(__('keywords.Toggle this switch element on for Firebase for OTP')); ?></label>
                                                </div>
                                               
                                                </div>
                                              </div><br><br>
                                              <form class="forms-sample" action="<?php echo e(route('updatefirebase_iso')); ?>" method="post" enctype="multipart/form-data">
                                               <?php echo e(csrf_field()); ?>      
                                               <?php if($fb_iso): ?>
                                                <div class="row">
                                                  <div class="col-md-12">
                                                    <div class="form-group">
                                                       <label for="bmd-label-floating"><?php echo e(__('keywords.Firebase ISO(used for firebase otp)')); ?></label>
                                                    <input type="text" id="iso_code" class="form-control" value="<?php echo e($fb_iso->iso_code); ?>" name="iso_code">
                                                    </div>
                                                  </div>
                                                </div>
                                                <?php else: ?>
                                                <div class="row">
                                                  <div class="col-md-12">
                                                    <div class="form-group">
                                                     <label for="bmd-label-floating"><?php echo e(__('keywords.Firebase ISO(used for firebase otp)')); ?></label>
                                                    <input type="text" id="iso_code" class="form-control" placeholder="Firebase ISO code" name="iso_code" required>
                                                    </div>
                                                  </div>
                                                </div>
                                                <?php endif; ?>
                                                <button type="submit" class="btn btn-primary pull-center"><?php echo e(__('keywords.UPDATE')); ?></button>
                                                <div class="clearfix"></div>
                                                </form>
                                            </div>
                                          </div>
                    </div>
                  </div>
                </div>
                <!-- END #notifications -->
                
              <!-- BEGIN #app_settings -->
                <div id="appsettings" class="mb-5">
                  <h4><i class="far fa-copyright fa-fw"></i> <?php echo e(__('keywords.FCM Keys')); ?></h4>
                  <p>fcm keys.</p>
                  <div class="col-md-12">
                                      <div class="card">
                                        <div class="card-header card-header-primary">
                                          <h4 class="card-title"><?php echo e(__('keywords.FCM Server Key')); ?></h4>
                                          <form class="forms-sample" action="<?php echo e(route('updatefcm')); ?>" method="post" enctype="multipart/form-data">
                                              <?php echo e(csrf_field()); ?>

                                        </div>
                                        <div class="card-body">
                                             <div class="row">
                                               <div class="col-md-12">
                                                <div class="form-group">
                                                  <label class="bmd-label-floating"><?php echo e(__('keywords.User App FCM Server Key')); ?></label>
                                                  <input type="text" name="fcm" value="<?php echo e(($fcm->server_key)); ?>" class="form-control">
                                                </div>
                                              </div>
                        
                                            </div>
                                            <div class="row">
                                               <div class="col-md-12">
                                                <div class="form-group">
                                                  <label class="bmd-label-floating"><?php echo e(__('keywords. App FCM Server Key')); ?></label>
                                                  <input type="text" name="fcm2" value="<?php echo e(($fcm->store_server_key)); ?>" class="form-control">
                                                </div>
                                              </div>
                        
                                            </div>
                                            <div class="row">
                                               <div class="col-md-12">
                                                <div class="form-group">
                                                  <label class="bmd-label-floating"><?php echo e(__('keywords.Driver App FCM Server Key')); ?></label>
                                                  <input type="text" name="fcm3" value="<?php echo e(($fcm->driver_server_key)); ?>" class="form-control">
                                                </div>
                                              </div>
                        
                                            </div>
                                            <button type="submit" class="btn btn-primary pull-center"><?php echo e(__('keywords.UPDATE')); ?></button>
                                            <div class="clearfix"></div>
                                          </form>
                                        </div>
                                      </div>
                                     </div> 
                              </div>
                <!-- END App Settings -->
                
                <!-- BEGIN #payment -->
                <div id="payment" class="mb-5">
                  <h4><i class="far fa-credit-card fa-fw"></i> <?php echo e(__('keywords.Payment')); ?></h4>
                  <p><?php echo e(__('keywords.Manage your payment provider')); ?></p>
           <div class="card">
                <div class="card-header card-header-primary">
                  <h4 class="card-title"><?php echo e(__('keywords.Payment Gateways')); ?></h4>
                </div>
            <div class="card-body">
                
                
              <h5 class="header-title"><?php echo e(__('keywords.Choose One')); ?> <?php echo e(__('keywords.Payment Gateways')); ?></h5>
                <div class="params-panel border border-dark p-3">
                  <div class="row">
                    <div class="col-md-12">
                     
               <form method="post" class="appsvan-submit params-panel" autocomplete="off" action="<?php echo e(route('gateway_status')); ?>" enctype="multipart/form-data">
                <?php echo e(csrf_field()); ?>   
                      <div class="form-group">
                      <label class="control-label"><?php echo e(__('keywords.Choose One')); ?></label>           
                      <select class="form-control" name="gateway" required>
                         <option value="razorpay" <?php echo e(get_option('razorpay_active') == 'Yes' ? 'selected' : ''); ?>><?php echo e(__('keywords.Razorpay')); ?></option>
                         <option value="paypal" <?php echo e(get_option('paypal_active') == 'Yes' ? 'selected' : ''); ?>><?php echo e(__('keywords.PayPal')); ?></option>
                         <option value="stripe" <?php echo e(get_option('stripe_active') == 'Yes' ? 'selected' : ''); ?>><?php echo e(__('keywords.Stripe')); ?></option>
                         <option value="paystack" <?php echo e(get_option('paystack_active') == 'Yes' ? 'selected' : ''); ?>><?php echo e(__('keywords.Paystack')); ?></option>
                      </select>
                      </div>
                      <br>
                        <div class="row">
                          <div class="col-md-12">
                            <div class="form-group">
                            <button type="submit" class="btn btn-primary"><?php echo e(__('keywords.Update')); ?></button>
                            </div>
                          </div>              
                        </div> 
                      </form>
                    </div>

                    
                  </div>
                </div>
                
                <br>
             

               <form method="post" class="appsvan-submit params-panel" autocomplete="off" action="<?php echo e(route('updategateway')); ?>" enctype="multipart/form-data">
                <?php echo e(csrf_field()); ?>

                
                <h5 class="header-title"><?php echo e(__('keywords.PayPal')); ?></h5>
                <div class="params-panel border border-dark p-3">
                  <div class="row">
                    <div class="col-md-4">
                      <div class="form-group">
                      <label class="control-label"><?php echo e(__('keywords.PayPal Active')); ?></label>           
                      <select class="form-control" disabled>
                         <option value="Yes"  <?php echo e(get_option('paypal_active') == 'Yes' ? 'selected' : ''); ?>><?php echo e(__('keywords.Yes')); ?></option>
                         <option value="No"  <?php echo e(get_option('paypal_active') == 'No' ? 'selected' : ''); ?>><?php echo e(__('keywords.No')); ?></option>
                      </select>
                      </div>
                    </div>
                    
                  <div class="col-md-4">
                      <div class="form-group">
                      <label class="control-label"><?php echo e(__('keywords.Client ID')); ?></label>           
                      <input type="text" class="form-control" name="paypal_client_id" value="<?php echo e(get_option('paypal_client_id')); ?>">
                      </div>
                    </div>
                    
                    <div class="col-md-4">
                      <div class="form-group">
                      <label class="control-label"><?php echo e(__('keywords.Secret Key')); ?></label>            
                      <input type="text" class="form-control" name="paypal_secret_key" value="<?php echo e(get_option('paypal_secret_key')); ?>">
                      </div>
                    </div>

                    
                  </div>
                </div>
                
                <br>
                <h5 class="header-title"><?php echo e(__('keywords.Stripe')); ?></h5>
                <div class="params-panel border border-dark p-3">
                  <div class="row">
                    <div class="col-md-3">
                      <div class="form-group">
                      <label class="control-label"><?php echo e(__('keywords.Stripe Active')); ?></label>           
                      <select class="form-control" disabled>
                         <option value="Yes"  <?php echo e(get_option('stripe_active') == 'Yes' ? 'selected' : ''); ?>><?php echo e(__('keywords.Yes')); ?></option>
                         <option value="No"  <?php echo e(get_option('stripe_active') == 'No' ? 'selected' : ''); ?>><?php echo e(__('keywords.No')); ?></option>
                      </select>
                      </div>
                    </div>
                    
                    <div class="col-md-3">
                      <div class="form-group">
                      <label class="control-label"><?php echo e(__('keywords.Secret Key')); ?></label>            
                      <input type="text" class="form-control" name="stripe_secret_key" value="<?php echo e(get_option('stripe_secret_key')); ?>">
                      </div>
                    </div>
                    
                    <div class="col-md-3">
                      <div class="form-group">
                      <label class="control-label"><?php echo e(__('keywords.Publishable Key')); ?></label>           
                      <input type="text" class="form-control" name="stripe_publishable_key" value="<?php echo e(get_option('stripe_publishable_key')); ?>">
                      </div>
                    </div>
                      <div class="col-md-3">
                      <div class="form-group">
                      <label class="control-label"><?php echo e(__('keywords.Merchant_id')); ?></label>           
                      <input type="text" class="form-control" name="stripe_merchant_id" value="<?php echo e(get_option('stripe_merchant_id')); ?>">
                      </div>
                    </div>
                  </div>
                </div>

                <br>
                <h5 class="header-title"><?php echo e(__('keywords.Razorpay')); ?></h5>
                <div class="params-panel border border-dark p-3">
                  <div class="row">
                    <div class="col-md-4">
                      <div class="form-group">
                      <label class="control-label"><?php echo e(__('keywords.Razorpay Active')); ?></label>           
                      <select class="form-control" disabled>
                         <option value="No"  <?php echo e(get_option('razorpay_active') == 'Yes' ? 'selected' : ''); ?>><?php echo e(__('keywords.Yes')); ?></option>
                         <option value="Yes"  <?php echo e(get_option('razorpay_active') == 'No' ? 'selected' : ''); ?>><?php echo e(__('keywords.No')); ?></option>
                      </select>
                      </div>
                    </div>

                    <div class="col-md-4">
                      <div class="form-group">
                      <label class="control-label"><?php echo e(__('keywords.Key ID')); ?></label>            
                      <input type="text" class="form-control" name="razorpay_key_id" value="<?php echo e(get_option('razorpay_key_id')); ?>">
                      </div>
                    </div>
                    
                    <div class="col-md-4">
                      <div class="form-group">
                      <label class="control-label"><?php echo e(__('keywords.Secret Key')); ?></label>            
                      <input type="text" class="form-control" name="razorpay_secret_key" value="<?php echo e(get_option('razorpay_secret_key')); ?>">
                      </div>
                    </div>

                  </div>
                </div>


                <br>
                <h5 class="header-title"><?php echo e(__('keywords.Paystack')); ?></h5>
                <div class="params-panel border border-dark p-3">
                  <div class="row">
                    <div class="col-md-4">
                      <div class="form-group">
                      <label class="control-label"><?php echo e(__('keywords.Paystack Active')); ?></label>           
                      <select class="form-control"  disabled>
                         <option value="No"  <?php echo e(get_option('paystack_active') == 'Yes' ? 'selected' : ''); ?>><?php echo e(__('keywords.Yes')); ?></option>
                         <option value="Yes"  <?php echo e(get_option('paystack_active') == 'No' ? 'selected' : ''); ?>><?php echo e(__('keywords.No')); ?></option>
                      </select>
                      </div>
                    </div>

                    <div class="col-md-4">
                      <div class="form-group">
                      <label class="control-label"><?php echo e(__('keywords.Paystack Public Key')); ?></label>           
                      <input type="text" class="form-control" name="paystack_public_key" value="<?php echo e(get_option('paystack_public_key')); ?>">
                      </div>
                    </div>
                    
                    <div class="col-md-4">
                      <div class="form-group">
                      <label class="control-label"><?php echo e(__('keywords.Paystack Secret Key')); ?></label>           
                      <input type="text" class="form-control" name="paystack_secret_key" value="<?php echo e(get_option('paystack_secret_key')); ?>">
                      </div>
                    </div>

                  </div>
                </div>

                <br>
                <div class="row">
                  <div class="col-md-12">
                    <div class="form-group">
                    <button type="submit" class="btn btn-primary"><?php echo e(__('keywords.Update')); ?></button>
                    </div>
                  </div>              
                </div>              
              </form>
            </div>
           </div>
          </div>
              
                
                  <!-- BEGIN #map -->
                <div id="map" class="mb-5">
                  <h4><i class="far fa-bell fa-fw"></i> <?php echo e(__('keywords.Map Settings')); ?></h4>
                  <p><?php echo e(__('keywords.Map Settings')); ?></p>
                  <div class="card">
                    <div class="list-group list-group-flush">
                      <div class="list-group-item d-flex align-items-center">
                        <div class="flex-fill">
                          <div><?php echo e(__('keywords.Map Gateway')); ?></div>
                          <div class="text-gray-700 d-flex align-items-center">
                            <i class="fa fa-map fs-8px fa-fw text-success mr-1"></i>
                                                      <?php if($mset->mapbox == 1): ?> <?php echo e(__('keywords.Mapbox ON')); ?> &nbsp;<span style="height: 12px;width: 12px;background-color: red;border-radius: 50%;display: inline-block;" class="dot"></span> <?php endif; ?>
                                                      <?php if($mset->google_map == 1): ?> <?php echo e(__('keywords.Google map On')); ?> &nbsp;<span style="height: 12px;width: 12px;background-color: green;border-radius: 50%;display: inline-block;" class="dot"></span> <?php endif; ?> 
                          </div>
                        </div>
                        <div>
                          <a href="#modalEditmap" data-toggle="modal" class="btn btn-default width-100"><?php echo e(__('keywords.Edit')); ?></a>
                        </div>
                      </div>
                                      
                    </div>
                  </div>
                </div>
                <!-- END #notifications -->
                
              <!-- BEGIN #Incentive -->
                <div id="incentive" class="mb-5">
                  <h4><i class="far fa-hdd fa-fw"></i> <?php echo e(__('keywords.Driver Incentive')); ?>  (<?php echo e($currency->currency_sign); ?>)</h4>
                  <p><?php echo e(__('keywords.Per Order')); ?></p>
                  <div class="card">
                                    <div class="card-header card-header-primary">
                                      <h4 class="card-title"><?php echo e(__('keywords.Driver Incentive')); ?> (<?php echo e($currency->currency_sign); ?>)</h4>
                                      <form class="forms-sample" action="<?php echo e(route('up_admin_incentive')); ?>" method="post" enctype="multipart/form-data">
                                          <?php echo e(csrf_field()); ?>

                                    </div>
                                    <div class="card-body">
                                         <div class="row">
                                           <div class="col-md-12">
                                            <div class="form-group">
                                              <label><?php echo e(__('keywords.Driver Incentive')); ?> <?php echo e(__('keywords.Per Order')); ?></label>
                                              <input type="number" name="incentive" <?php if($incentive): ?> value="<?php echo e($incentive->incentive); ?>" <?php endif; ?>  class="form-control">
                                            </div>
                                          </div>
     
                                        </div><br>
                                        <button type="submit" class="btn btn-primary pull-center"><?php echo e(__('keywords.Update')); ?></button>
                                        <div class="clearfix"></div>
                                    </div>
                                      </form>
                                  </div>
                </div>
                
                <!-- BEGIN #notice -->
                <div id="notice" class="mb-5">
                  <h4><i class="far fa-hdd fa-fw"></i> <?php echo e(__('keywords.App Notice')); ?></h4>
                  <p><?php echo e(__('keywords.App Notice')); ?></p>
                  <div class="card">
                                    <div class="card-header card-header-primary">
                                      <h4 class="card-title"><?php echo e(__('keywords.App Notice')); ?></h4>
                                      <form class="forms-sample" action="<?php echo e(route('app_noticeupdate')); ?>" method="post" enctype="multipart/form-data">
                                          <?php echo e(csrf_field()); ?>

                                    </div>
                                    <div class="card-body">
                                         <div class="row">
                                           
                                          <div class="col-md-12">
                                            <div class="form-group">
                                                <div class="col-md-4" style="float:left">
                                               <input type="radio" id="male" name="status" value="1" <?php if($notice->status == 1): ?> checked <?php endif; ?>>
                                                  <label for="On"><?php echo e(__('keywords.Active')); ?></label>
                                                  </div>
                                                  <div class="col-md-4" style="float:left">
                                                  <input type="radio" id="female" name="status" value="0" <?php if($notice->status == 0): ?> checked <?php endif; ?>>
                                                  <label for="Off"><?php echo e(__('keywords.Inactive')); ?></label><br>
                                                  </div> 
                                             
                                            </div>
                                          </div><br><br>
                                           <div class="col-md-12">
                                            <div class="form-group">
                                              <label>Notice</label>
                                              <textarea name="notice" minlength="20" class="form-control"><?php if($notice): ?> <?php echo e($notice->notice); ?> <?php endif; ?></textarea>
                                            </div>
                                          </div>

                                        </div><br>
                                        <button type="submit" class="btn btn-primary pull-center"><?php echo e(__('keywords.Update Notice')); ?></button>
                                        <div class="clearfix"></div>
                                    </div>
                                      </form>
                                  </div>
                </div>
                <!-- END #system -->
                
                
                  <!-- BEGIN #app link -->
                <div id="applink" class="mb-5">
                  <h4><i class="far fa-hdd fa-fw"></i> <?php echo e(__('keywords.App Links')); ?></h4>
                  <p><?php echo e(__('keywords.App Links')); ?></p>
                  <div class="card">
                                    <div class="card-header card-header-primary">
                                      <h4 class="card-title"><?php echo e(__('keywords.App Link')); ?></h4>
                                      <form class="forms-sample" action="<?php echo e(route('app_link')); ?>" method="post" enctype="multipart/form-data">
                                          <?php echo e(csrf_field()); ?>

                                    </div>
                                    <div class="card-body">
                                         <div class="row">
                                           
                                           <div class="col-md-12">
                                            <div class="form-group">
                                              <label><?php echo e(__('keywords.Android')); ?> <?php echo e(__('keywords.App Link')); ?></label>
                                              <textarea name="an_link" class="form-control"><?php if($app_link): ?> <?php echo e($app_link->android_app_link); ?> <?php endif; ?></textarea>
                                            </div>
                                          </div>
                                          <div class="col-md-12">
                                            <div class="form-group">
                                              <label><?php echo e(__('keywords.IOS')); ?> <?php echo e(__('keywords.App Link')); ?></label>
                                              <textarea name="ios_link" class="form-control"><?php if($app_link): ?> <?php echo e($app_link->ios_app_link); ?> <?php endif; ?></textarea>
                                            </div>
                                          </div>
                                        </div><br>
                                        <button type="submit" class="btn btn-primary pull-center"><?php echo e(__('keywords.Update')); ?></button>
                                        <div class="clearfix"></div>
                                    </div>
                                      </form>
                                  </div>
                </div>
                <!-- END #system -->


                  <!-- BEGIN #app link -->
                <div id="otherspace" class="mb-5">
                  <h4><i class="far fa-hdd fa-fw"></i> <?php echo e(__('keywords.Images Space')); ?></h4>
                  <p><?php echo e(__('keywords.Choose Images Space')); ?></p>
                  <div class="card">
                                    <div class="card-header card-header-primary">
                                      <h4 class="card-title"><?php echo e(__('keywords.Images Space')); ?></h4>
                                      <form class="forms-sample" action="<?php echo e(route('updatespace')); ?>" method="post" enctype="multipart/form-data">
                                          <?php echo e(csrf_field()); ?>

                                    </div>
                                    <div class="card-body">
                                         <div class="row">
                                           
                                           <div class="col-md-12">
                                            <div class="form-group">
                                             <select name="status" class="form-control">
                                            <?php if($space): ?>
                                              <option value="do" <?php if($space->digital_ocean==1): ?> selected <?php endif; ?>><?php echo e(__('keywords.Digital Ocean')); ?></option>
                                                <option value="aws" <?php if($space->aws==1): ?> selected <?php endif; ?>><?php echo e(__('keywords.AWS')); ?></option>
                                                
                                                <option value="ss" <?php if($space->same_server==1): ?> selected <?php endif; ?>><?php echo e(__('keywords.Same Server')); ?></option>
                                              <?php else: ?>  
                                               <option value="do"><?php echo e(__('keywords.Digital Ocean')); ?></option>
                                                <option value="aws"><?php echo e(__('keywords.Aws')); ?></option>
                                                 <option value="ss"><?php echo e(__('keywords.Same Server')); ?></option>
                                               <?php endif; ?> 
                                             </select>
                                            </div>
                                          </div>
                                         
                                        </div><br>
                                        <button type="submit" class="btn btn-primary pull-center"><?php echo e(__('keywords.Update')); ?></button>
                                        <div class="clearfix"></div>
                                    </div>
                                      </form>
                                  </div>
                </div>
                <!-- END #system -->
          
              </div>
              <!-- END col-9-->
              <!-- BEGIN col-3 -->
              <div class="col-xl-3">
                <!-- BEGIN #sidebar-bootstrap -->
                <nav id="sidebar-bootstrap" class="navbar navbar-sticky d-none d-xl-block">
                  <nav class="nav">
                    <a class="nav-link" href="#general" data-toggle="scroll-to"><?php echo e(__('keywords.Global Settings')); ?></a>
                    <a class="nav-link" href="#sms" data-toggle="scroll-to"><?php echo e(__('keywords.SMS/OTP Settings')); ?></a>
                    <a class="nav-link" href="#appsettings" data-toggle="scroll-to"><?php echo e(__('keywords.FCM Keys')); ?></a>
                    <a class="nav-link" href="#payment" data-toggle="scroll-to"><?php echo e(__('keywords.Payment Mode')); ?></a>
                    <a class="nav-link" href="#map" data-toggle="scroll-to"><?php echo e(__('keywords.MAP Settings')); ?></a>
                    <a class="nav-link" href="#incentive" data-toggle="scroll-to"><?php echo e(__('keywords.Driver Incentive')); ?>(<?php echo e(__('keywords.Per Order')); ?>)</a>
                    <a class="nav-link" href="#notice" data-toggle="scroll-to"><?php echo e(__('keywords.App Notice')); ?></a>
                    <a class="nav-link" href="#applink" data-toggle="scroll-to"><?php echo e(__('keywords.App Link')); ?></a>
                    <a class="nav-link" href="#otherspace" data-toggle="scroll-to"><?php echo e(__('keywords.Images Store')); ?></a>
                    
                  </nav>
                </nav>
                <!-- END #sidebar-bootstrap -->
              </div>
              <!-- END col-3 -->
            </div>
            <!-- END row -->
          </div>
          <!-- END col-10 -->
        </div>
        <!-- END row -->
      </div>
      <!-- END container -->
          
          
     
          
            <!-- BEGIN #modalEditsms -->
    <div class="modal fade" id="modalEditsms">
      <div class="modal-dialog">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title"><?php echo e(__('keywords.Edit')); ?> <?php echo e(__('keywords.SMS Gateway')); ?></h5>
            <button type="button" class="close" data-dismiss="modal">
              <span>×</span>
            </button>
          </div>
          <div class="modal-body">
             <div class="form-group"> 
                         <div> 
                         <div class="col-md-4" style="float:left">
                                <label class="radicont"> 
                                    <input type="radio" name="colorRadio" 
                                           value="msg91" class="radio" <?php if($smsby->status == 1 && $smsby->twilio == 0 && $smsby->msg91 == 1): ?> checked <?php endif; ?>> <span class="radio"></span>Msg91</label>
                            </div> 
                            <div class="col-md-4" style="float:left">
                                <label class="radicont"> 
                                    <input type="radio" name="colorRadio" 
                                           value="twilio" class="radio" <?php if($smsby->status == 1 && $smsby->twilio == 1 && $smsby->msg91 == 0): ?> checked <?php endif; ?>> <span class="radio"></span> Twilio </label> 
                                  </div> 
                            <div class="col-md-4" style="float:left">      
                                <label class="radicont"> 
                                    <input type="radio" name="colorRadio" 
                                           value="msgoff" class="radio" <?php if($smsby->status == 0 && $smsby->twilio == 0 && $smsby->msg91 == 0): ?> checked <?php endif; ?>> <span class="radio"></span> <?php echo e(__('keywords.Off')); ?> </label> 
                                </div>            
                            </div> 
                         <br><br> <hr>   
                           <div id="dvPassport" style="display: none" class="msg91 selectt">
                       
                                  <form class="forms-sample" action="<?php echo e(route('updatemsg91')); ?>" method="post" enctype="multipart/form-data">
                                      <?php echo e(csrf_field()); ?>

                                <div class="card-body">
                                     <?php if($msg91): ?>
                                     <div class="row">
                                      <div class="col-md-6">
                                        <div class="form-group">
                                          <label class="bmd-label-floating"><?php echo e(__('keywords.Sender ID')); ?></label>
                                          <input type="text" name="sender_id" value="<?php echo e(($msg91->sender_id)); ?>" class="form-control">
                                        </div>
                                      </div>
                                       <div class="col-md-6">
                                        <div class="form-group">
                                          <label class="bmd-label-floating"><?php echo e(__('keywords.Msg91 API Key')); ?></label>
                                          <input type="text" name="api" value="<?php echo e(($msg91->api_key)); ?>" class="form-control">
                                        </div>
                                      </div>
                
                                    </div>
                                    <?php else: ?>
                                     <div class="row">
                                      <div class="col-md-6">
                                        <div class="form-group">
                                          <label class="bmd-label-floating"><?php echo e(__('keywords.Sender ID')); ?></label>
                                          <input type="text" name="sender_id" placeholder="Insert Sender Id Of Six Letters Only" class="form-control" required>
                                        </div>
                                      </div>
                                       <div class="col-md-6">
                                        <div class="form-group">
                                          <label class="bmd-label-floating"><?php echo e(__('keywords.Msg91 API Key')); ?></label>
                                          <input type="text" name="api" placeholder="Msg91 API Key" class="form-control" required>
                                        </div>
                                      </div>
                
                                    </div>
                                    <?php endif; ?>
                                     <div class="modal-footer">
                                     <button type="submit" class="btn btn-primary pull-center"><?php echo e(__('keywords.Msg91 ON')); ?></button>
                                     <button type="button" class="btn btn-default" data-dismiss="modal"><?php echo e(__('keywords.Close')); ?></button>
                                    <div class="clearfix"></div>
                                    </div>
                                  </form>
                              </div>              
                            </div>
                             
                        <div id="dv2Passport" style="display: none" class="twilio selectt">
                           <form class="forms-sample" action="<?php echo e(route('updatetwilio')); ?>" method="post" enctype="multipart/form-data">
                              <?php echo e(csrf_field()); ?>      
                                   <?php if($twilio): ?>
                                    <div class="row">
                                      <div class="col-md-4">
                                        <div class="form-group">
                                           <label for="bmd-label-floating">Twilio SID</label>
                                        <input type="text" id="sid" class="form-control" value="<?php echo e($twilio->twilio_sid); ?>" name="sid">
                                        </div>
                                      </div>
                                       <div class="col-md-4">
                                        <div class="form-group">
                                          <label for="bmd-label-floating">Twilio Token</label>
                                        <input type="text" id="token" class="form-control" value="<?php echo e($twilio->twilio_token); ?>" name="token">
                                        </div>
                                      </div>
                                      <div class="col-md-4">
                                        <div class="form-group">
                                         <label for="bmd-label-floating">Twilio Phone</label>
                                        <input type="text" id="phone" class="form-control" value="<?php echo e($twilio->twilio_phone); ?>" name="phone">
                                        </div>
                                      </div>
                                    </div>
                                    <?php else: ?>
                                    <div class="row">
                                      <div class="col-md-4">
                                        <div class="form-group">
                                         <label for="bmd-label-floating">Twilio SID</label>
                                        <input type="text" id="sid" class="form-control" placeholder="Twilio SID" name="sid" required>
                                        </div>
                                      </div>
                                       <div class="col-md-4">
                                        <div class="form-group">
                                          <label for="bmd-label-floating">Twilio Token')}}</label>
                                        <input type="text" id="token" class="form-control" placeholder="Twilio Token" name="token" required>
                                        </div>
                                      </div>
                                      <div class="col-md-4">
                                        <div class="form-group">
                                         <label for="bmd-label-floating">Twilio Phone</label>
                                        <input type="text" id="phone" class="form-control" placeholder="Twilio Phone" name="phone" required>
                                        </div>
                                      </div>
                                    </div>
                                    <?php endif; ?>
                                    <div class="modal-footer">
                                     <button type="submit" class="btn btn-primary pull-center"><?php echo e(__('keywords.Twilio ON')); ?></button>
                                     <button type="button" class="btn btn-default" data-dismiss="modal"><?php echo e(__('keywords.Close')); ?></button>
                                    <div class="clearfix"></div>
                                    </div>
                                    </form>
                              </div> 
                          
                            <div id="dv3Passport" style="display: none" class="msgoff selectt">
                             <form class="forms-sample" action="<?php echo e(route('msgoff')); ?>" method="post" enctype="multipart/form-data">
                              <?php echo e(csrf_field()); ?> 
                              <div class="modal-footer">
                             <button type="submit" class="btn btn-primary pull-center"><?php echo e(__('keywords.Otp/SMS OFF')); ?></button>
                             <button type="button" class="btn btn-default" data-dismiss="modal"><?php echo e(__('keywords.Close')); ?></button>
                            <div class="clearfix"></div>
                            </div>
                            </form>
                             </div> 
                    
                    
                        </div>

          </div>
        </div>
      </div>
    </div>
    <!-- END #modalEdit -->

    <script>
    let elems = Array.prototype.slice.call(document.querySelectorAll('.customSwitch1'));

    elems.forEach(function(html) {
    let switchery = new Switchery(html,  { size: 'small' });
    });
    </script>
<script>
    $(document).ready(function(){
    $('.customSwitch1').change(function () {
        let status = $(this).prop('checked') === true ? 1 : 0;
        $.ajax({
            type: "GET",
            dataType: "json",
            url: '<?php echo e(route("updatefirebase")); ?>',
            data: {'status': status},
            success: function (data) {
                console.log(data.message);
            }
        });
    });
});
</script> 
          
          
 <script type="text/javascript"> 
    $(document).ready(function() { 
        $('input[type="radio"]').click(function() { 
            var inputValue = $(this).attr("value"); 
            var targetBox = $("." + inputValue); 
            $(".selectt").not(targetBox).hide(); 
            $(targetBox).show(); 
        }); 
    }); 
 </script> 
 
<script type="text/javascript">
  var value = <?php echo e($smsby->twilio); ?>;
  var status = <?php echo e($smsby->status); ?>;
  if(value=='1' && status == '1')
  {
    $('#dv2Passport').show();
  }
  else
  {
    $('#dv2Passport').hide();
  }
  
</script>
<script type="text/javascript">
  var value = <?php echo e($smsby->msg91); ?>;
  var status = <?php echo e($smsby->status); ?>;
  if(value=='1' && status == '1')
  {
    $('#dvPassport').show();
  }
  else
  {
    $('#dvPassport').hide();
  }
  
</script>

<script type="text/javascript">
  var value = <?php echo e($smsby->msg91); ?>;
  var twilio = <?php echo e($smsby->twilio); ?>;
  var status = <?php echo e($smsby->status); ?>;
  if(value=='0' && status == '0' && twilio == '0')
  {
    $('#dv3Passport').show();
  }
  else
  {
    $('#dv3Passport').hide();
  }
  
</script>




   
            <!-- BEGIN #modalEditmap -->
    <div class="modal fade" id="modalEditmap">
      <div class="modal-dialog">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title">Edit Map Settings</h5>
            <button type="button" class="close" data-dismiss="modal">
              <span>×</span>
            </button>
          </div>
          <div class="modal-body">
                 <div class="form-group">    
                  <div class="col-md-6" style="float:left">
                        <label class="radicont"> 
                            <input type="radio" name="colorRadio" 
                                   value="mapbox" class="radio" <?php if($mset->mapbox == 1): ?> checked <?php endif; ?>><span class="radio"></span>Mapbox</label>
                    </div> 
                    <div class="col-md-6" align="center" style="float:left">
                        <label class="radicont"> 
                            <input type="radio" name="colorRadio" 
                                   value="google_map" class="radio" <?php if($mset->google_map == 1): ?> checked <?php endif; ?>><span class="radio"></span> Google Map </label> 
                          </div> 
                    </div><br><br><hr>      
            
                 <div class="col-md-12" style="float:left">
                       <div id="dv5Passport" style="display: none" class="mapbox selectt">
                   
                              <form class="forms-sample" action="<?php echo e(route('updatemapbox')); ?>" method="post" enctype="multipart/form-data">
                                  <?php echo e(csrf_field()); ?>

                            <div class="card-body">
                                 <?php if($m): ?>
                                 <div class="row">
                                  
                                   <div class="col-md-12">
                                    <div class="form-group">
                                      <label class="bmd-label-floating">Mapbox API Key</label>
                                      <input type="text" name="mapbox" value="<?php echo e(($m->mapbox_api)); ?>" class="form-control">
                                    </div>
                                  </div>
            
                                </div>
                                <?php else: ?>
                                 <div class="row">
                                    <div class="col-md-12">
                                    <div class="form-group">
                                      <label class="bmd-label-floating">Mapbox API Key</label>
                                      <input type="text" name="mapbox" placeholder="mapbox api key" class="form-control">
                                    </div>
                                  </div>
            
            
                                </div>
                                <?php endif; ?>
                               <div class="modal-footer">
                             <button type="submit" class="btn btn-primary pull-center">Mapbox On</button>
                             <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                            <div class="clearfix"></div>
                            </div>
                              </form>
                          </div>              
                        </div>
                         
                    <div id="dv6Passport" style="display: none" class="google_map selectt">
                       <form class="forms-sample" action="<?php echo e(route('updatemap')); ?>" method="post" enctype="multipart/form-data">
                          <?php echo e(csrf_field()); ?>      
                               <?php if($g): ?>
                                <div class="row">
                                  <div class="col-md-12">
                                    <div class="form-group">
                                       <label for="bmd-label-floating">Google map</label>
                                    <input type="text" id="api" class="form-control" value="<?php echo e($g->map_api_key); ?>" name="api">
                                    </div>
                                  </div>
                                </div>
                                <?php else: ?>
                                <div class="row">
                                 <div class="form-group">
                                       <label for="bmd-label-floating">Google map</label>
                                    <input type="text" id="api" class="form-control" placeholder="map api key" name="api">
                                    </div>
                                </div>
                                <?php endif; ?>
                                <div class="modal-footer">
                             <button type="submit" class="btn btn-primary pull-center">Google Map ON</button>
                             <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                            <div class="clearfix"></div>
                            </div>
                                </form>
                          </div> 
                      
                          </div>

          </div>
        </div>
      </div>
    </div>
    <!-- END #modalEdit -->


<script type="text/javascript">
  var value = <?php echo e($mset->mapbox); ?>;
  if(value=='1')
  {
    $('#dv5Passport').show();
  }
  else
  {
    $('#dv5Passport').hide();
  }
  
</script>
<script type="text/javascript">
  var value = <?php echo e($mset->google_map); ?>;
  if(value=='1')
  {
    $('#dv6Passport').show();
  }
  else
  {
    $('#dv6Passport').hide();
  }
  
</script>
        
<?php $__env->stopSection(); ?>





<?php echo $__env->make('admin.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\projectfiles\source\resources\views/admin/settings/app_details.blade.php ENDPATH**/ ?>