
<style>
   
    .material-icons{
        margin-top:0px !important;
        margin-bottom:0px !important;
    }
    .dt-buttons > button.btn.btn-secondary {
    background-color: grey;
    margin: 1px;
    border-radius: 5px;
    color: white;
}
</style>
<?php $__env->startSection('content'); ?>
<div class="container-fluid">
 <div class="row">
<div class="col-lg-12">
    <?php if(session()->has('success')): ?>
   <div class="alert alert-success">
    <?php if(is_array(session()->get('success'))): ?>
            <ul>
                <?php $__currentLoopData = session()->get('success'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($message); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
            <?php else: ?>
                <?php echo e(session()->get('success')); ?>

            <?php endif; ?>
        </div>
    <?php endif; ?>
     <?php if(count($errors) > 0): ?>
      <?php if($errors->any()): ?>
        <div class="alert alert-danger" role="alert">
          <?php echo e($errors->first()); ?>

          <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">×</span>
          </button>
        </div>
      <?php endif; ?>
    <?php endif; ?>
    </div>

<div class="col-lg-12">
   
<div class="card">    
<div class="card-header card-header-primary">
      <h4 class="card-title "><?php echo e(__('keywords.Item Sales Report')); ?> (<?php echo e(__('keywords.Last 30 Days')); ?>)</h4>
    </div>

<div class="container"> <br> 
<table id="datatableDefault" class="table text-nowrap w-100">
    <thead class="thead-light">
        <tr>
            <th>#</th>
            <th><?php echo e(__('keywords.Product')); ?> <?php echo e(__('keywords.Name')); ?></th>
            <th><?php echo e(__('keywords.Stock')); ?></th>
        </tr>
    </thead>
    <tbody>
           <?php if(count($ord)>0): ?>
          <?php $i=1; ?>
          <?php $__currentLoopData = $ord; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ords): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td class="text-center"><?php echo e($i); ?></td>
            <td><?php echo e($ords->product_name); ?></td>
            
            <td><?php $__currentLoopData = $det; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dets): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($dets->product_id == $ords->product_id): ?>
                <?php echo e($dets->quantity); ?><?php echo e($dets->unit); ?> * <?php echo e($dets->count* $dets->sumqty); ?><b>(<?php echo e($dets->quantity*$dets->count*$dets->sumqty); ?><?php echo e($dets->unit); ?>)</b> |
                <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></td>

            
        </tr>
          <?php $i++; ?>
                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  <?php else: ?>
                    <tr>
                      <td><?php echo e(__('keywords.No data found')); ?></td>
                    </tr>
                  <?php endif; ?>
    </tbody>
</table>
</div>  
</div>
</div>
</div>
</div>
<div>
    </div>
    <?php $__env->stopSection(); ?>
</div>
<?php echo $__env->make('store.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u518557422/domains/themeatzheaven.online/public_html/source/resources/views/store/stockthirty.blade.php ENDPATH**/ ?>