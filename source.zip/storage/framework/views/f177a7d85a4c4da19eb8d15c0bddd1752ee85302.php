
<?php use Carbon\carbon;
?>
<style>

    .material-icons{
        margin-top:0px !important;
        margin-bottom:0px !important;
    }
</style>
<?php $__env->startSection('content'); ?>
<div class="container-fluid">
 <div class="row">
<div class="col-lg-12">
<?php if(session()->has('success')): ?>
<div class="alert alert-success">
<?php if(is_array(session()->get('success'))): ?>
        <ul>
            <?php $__currentLoopData = session()->get('success'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($message); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
        <?php else: ?>
            <?php echo e(session()->get('success')); ?>

        <?php endif; ?>
    </div>
<?php endif; ?>
 <?php if(count($errors) > 0): ?>
  <?php if($errors->any()): ?>
    <div class="alert alert-danger" role="alert">
      <?php echo e($errors->first()); ?>

      <button type="button" class="close" data-dismiss="alert" aria-label="Close">
        <span aria-hidden="true">×</span>
      </button>
    </div>
  <?php endif; ?>
<?php endif; ?>
</div>
<div class="col-lg-12">
    <hr><br><br>
    </div>
<div class="col-lg-12">
   <div class="separator"><h4 style="color:grey"><?php echo e(__('keywords.Delivery Boy')); ?> <?php echo e(__('keywords.Reports')); ?></h4></div><hr>
<style>
.separator {
    display: flex;
    align-items: center;
    text-align: center;
}
.separator::before, .separator::after {
    content: '';
    flex: 1;
    border-bottom: 1px solid #000;
}
.separator::before {
    margin-right: .25em;
}
.separator::after {
    margin-left: .25em;
}
</style>

</div>
<div class="col-lg-5">
<div class="card">    
<div class="card-header card-header-primary">
      <h4 class="card-title "><?php echo e(__('keywords.Top Delivery Boys')); ?></h4>
     
    </div>
<div class="container"> <br> 
<table id="datatableDefault" class="table text-nowrap w-100">
    <thead class="thead-light">
        <tr>
            <th class="text-center">#</th>
                      <!--<th>ID</th>-->
                      <th><?php echo e(__('keywords.Delivery Boy')); ?></th>
                      <th><?php echo e(__('keywords.Last 30 Days')); ?> <?php echo e(__('keywords.Orders')); ?></th>
                    </thead>
                    <tbody>
                         <?php if(count($orddboy)>0): ?>
                          <?php $i=1; ?>
                          <?php $__currentLoopData = $orddboy; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $orddboys): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td class="text-center"><?php echo e($i); ?></td>
                                <td><?php echo e($orddboys->boy_name); ?><p style="font-size:14px">(<?php echo e($orddboys->boy_phone); ?>)</p></td>
                                     
                                <td><?php echo e($orddboys->count); ?></td>
                              
                            </tr>      
                        <?php $i++; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      <?php else: ?>
                        <tr>
                          <td><?php echo e(__('keywords.No data found')); ?></td>
                        </tr>
                      <?php endif; ?>  
                    </tbody>
</table>

</div>
</div>
</div>
<div class="col-lg-7">
<div class="card">    
<div class="card-header card-header-primary">
      <h4 class="card-title "><?php echo e(__('keywords.Delivery Boy')); ?> <?php echo e(__('keywords.Orders')); ?> <?php echo e(__('keywords.Reports')); ?></h4>
     
    </div>
<div class="container"> <br> 
<table id="datatableDefaults" class="table text-nowrap w-100">
    <thead class="thead-light">
        <tr>
            <th class="text-center">#</th>
                      <!--<th>ID</th>-->
                      <th><?php echo e(__('keywords.Delivery Boy')); ?></th>
                      <th><?php echo e(__('keywords.Last 30 Days')); ?> <?php echo e(__('keywords.Orders')); ?></th>
                      <th><?php echo e(__('keywords.Previous Month')); ?> <?php echo e(__('keywords.Orders')); ?></th>
                      <th><?php echo e(__('keywords.Last 3 Months')); ?> <?php echo e(__('keywords.Orders')); ?></th>
                     
                    </thead>
                    <tbody>
                         <?php if(count($dboy)>0): ?>
                          <?php $i=1; ?>
                          <?php $__currentLoopData = $dboy; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dboys): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td class="text-center"><?php echo e($i); ?></td>
                                <td><?php echo e($dboys->boy_name); ?><p style="font-size:14px">(<?php echo e($dboys->boy_phone); ?>)</p></td>
                                <?php  
                                
                                $ordthirty =DB::table('orders')
                                         ->select('dboy_id', 'cart_id')
                                         ->whereDate('delivery_date', '>', Carbon::now()->subDays(30))
                                         ->where('payment_method','!=', NULL)
                                         ->where('order_status', 'Completed')
                                          ->where('dboy_id', $dboys->dboy_id)
                                         ->count();
             
                                  $ordmonth =DB::table('orders')
                                     ->select('dboy_id', 'cart_id')
                                     ->whereMonth('delivery_date', '=', Carbon::now()->subMonth()->month)
                                     ->where('payment_method','!=', NULL)
                                     ->where('order_status', 'Completed')
                                      ->where('dboy_id', $dboys->dboy_id)
                                     ->count();   
                                   
                                    $ord3month =DB::table('orders')
                                     ->select('dboy_id', 'cart_id')
                                     ->whereMonth('delivery_date', '=', Carbon::now()->subMonth(3)->month)
                                     ->where('payment_method','!=', NULL)
                                     ->where('order_status', 'Completed')
                                      ->where('dboy_id', $dboys->dboy_id)
                                     ->count();   
                                     ?>
                                     
                                <td><?php echo e($ordthirty); ?></td>
                                <td><?php echo e($ordmonth); ?></td>
                                <td><?php echo e($ord3month); ?></td>
                              
                            </tr>      
                        <?php $i++; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      <?php else: ?>
                        <tr>
                          <td><?php echo e(__('keywords.No data found')); ?></td>
                        </tr>
                      <?php endif; ?>  
                    </tbody>
</table>

</div>
</div>
</div>

<!--Store-->
<br><br>
<div class="col-lg-12">
    <hr><br><br>
    </div>
<div class="col-lg-12">
   <div class="separator"><h4 style="color:grey"><?php echo e(__('keywords.Store')); ?> <?php echo e(__('keywords.Reports')); ?></h4></div><hr>
<style>
.separator {
    display: flex;
    align-items: center;
    text-align: center;
}
.separator::before, .separator::after {
    content: '';
    flex: 1;
    border-bottom: 1px solid #000;
}
.separator::before {
    margin-right: .25em;
}
.separator::after {
    margin-left: .25em;
}
</style>

</div>
<div class="col-lg-5">
<div class="card">    
<div class="card-header card-header-primary">
      <h4 class="card-title "><?php echo e(__('keywords.Top Stores')); ?></h4>
     
    </div>
<div class="container"> <br> 
<table id="datatableDefault1" class="table text-nowrap w-100">
    <thead class="thead-light">
        <tr>
            <th class="text-center">#</th>
                      <!--<th>ID</th>-->
                      <th><?php echo e(__('keywords.Store')); ?></th>
                      <th><?php echo e(__('keywords.Last 30 Days')); ?> <?php echo e(__('keywords.Orders')); ?></th>
                    </thead>
                    <tbody>
                         <?php if(count($ordstore)>0): ?>
                          <?php $i=1; ?>
                          <?php $__currentLoopData = $ordstore; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ordstores): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td class="text-center"><?php echo e($i); ?></td>
                                <td><?php echo e($ordstores->store_name); ?><p style="font-size:14px">(<?php echo e($ordstores->phone_number); ?>)</p></td>
                                     
                                <td><?php echo e($ordstores->count); ?></td>
                              
                            </tr>      
                        <?php $i++; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      <?php else: ?>
                        <tr>
                          <td><?php echo e(__('keywords.No data found')); ?></td>
                        </tr>
                      <?php endif; ?>  
                    </tbody>
</table>

</div>
</div>
</div>
<div class="col-lg-7">
<div class="card">    
<div class="card-header card-header-primary">
      <h4 class="card-title "><?php echo e(__('keywords.Store')); ?> <?php echo e(__('keywords.Orders')); ?> <?php echo e(__('keywords.Reports')); ?></h4>
     
    </div>
<div class="container"> <br> 
<table id="datatableDefault2" class="table text-nowrap w-100">
    <thead class="thead-light">
        <tr>
            <th class="text-center">#</th>
                      <!--<th>ID</th>-->
                      <th><?php echo e(__('keywords.Store')); ?></th>
                      <th><?php echo e(__('keywords.Last 30 Days')); ?> <?php echo e(__('keywords.Orders')); ?></th>
                      <th><?php echo e(__('keywords.Previous Month')); ?> <?php echo e(__('keywords.Orders')); ?></th>
                      <th><?php echo e(__('keywords.Last 3 Months')); ?> <?php echo e(__('keywords.Orders')); ?></th>
                     
                    </thead>
                    <tbody>
                         <?php if(count($store)>0): ?>
                          <?php $i=1; ?>
                          <?php $__currentLoopData = $store; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $stores): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td class="text-center"><?php echo e($i); ?></td>
                                <td><?php echo e($stores->store_name); ?><p style="font-size:14px">(<?php echo e($stores->phone_number); ?>)</p></td>
                                <?php  
                                
                                $ordthirtystore =DB::table('orders')
                                         ->join('store','orders.store_id','=','store.id')
                                         ->whereDate('orders.delivery_date', '>', Carbon::now()->subDays(30))
                                         ->where('orders.payment_method','!=', NULL)
                                         ->where('orders.order_status', 'Completed')
                                          ->where('orders.store_id', $stores->id)
                                         ->count();
             
                                  $ordmonthstore =DB::table('orders')
                                  ->join('store','orders.store_id','=','store.id')
                                     ->whereMonth('orders.delivery_date', '=', Carbon::now()->subMonth()->month)
                                     ->where('orders.payment_method','!=', NULL)
                                    ->where('orders.order_status', 'Completed')
                                    ->where('orders.store_id', $stores->id)
                                     ->count();   
                                   
                                    $ord3monthstore =DB::table('orders')
                                    ->join('store','orders.store_id','=','store.id')
                                     ->whereMonth('orders.delivery_date', '=', Carbon::now()->subMonth(3)->month)
                                     ->where('orders.payment_method','!=', NULL)
                                     ->where('orders.order_status', 'Completed')
                                     ->where('orders.store_id', $stores->id)
                                     ->count();   
                                     ?>
                                     
                                <td><?php echo e($ordthirtystore); ?></td>
                                <td><?php echo e($ordmonthstore); ?></td>
                                <td><?php echo e($ord3monthstore); ?></td>
                              
                            </tr>      
                        <?php $i++; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      <?php else: ?>
                        <tr>
                          <td><?php echo e(__('keywords.No data found')); ?></td>
                        </tr>
                      <?php endif; ?>  
                    </tbody>
</table>

</div>
</div>
</div>

<div class="col-lg-12">
    <hr><br><br>
    </div>
<div class="col-lg-12">
   <div class="separator"><h4 style="color:grey"><?php echo e(__('keywords.Users')); ?> <?php echo e(__('keywords.Reports')); ?></h4></div><hr>
<style>
.separator {
    display: flex;
    align-items: center;
    text-align: center;
}
.separator::before, .separator::after {
    content: '';
    flex: 1;
    border-bottom: 1px solid #000;
}
.separator::before {
    margin-right: .25em;
}
.separator::after {
    margin-left: .25em;
}
</style>

</div>

<div class="col-lg-6">
<div class="card">    
<div class="card-header card-header-primary">
      <h4 class="card-title "><?php echo e(__('keywords.Top 10 Users')); ?> <?php echo e(__('keywords.Reports')); ?></h4>
     
    </div>
<div class="container"> <br> 
<table id="datatableDefaults3" class="table text-nowrap w-100">
    <thead class="thead-light">
        <tr>
            <th class="text-center">#</th>
                      <!--<th>ID</th>-->
                      <th><?php echo e(__('keywords.User')); ?></th>
                      <th><?php echo e(__('keywords.Current Month')); ?></th>
                      <th><?php echo e(__('keywords.Previous Month')); ?></th>
                      <th><?php echo e(__('keywords.Difference')); ?></th>
                     
                    </thead>
                    
                     <tbody>
                         <?php if(count($user)>0): ?>
                          <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $users): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                
                              <?php  
             
                                   $ordmonth2 =DB::table('orders')
                                     ->select('dboy_id', 'cart_id')
                                     ->whereMonth('delivery_date', '=', Carbon::now()->subMonth()->month)
                                     ->where('payment_method','!=', NULL)
                                     ->where('order_status', 'Completed')
                                     ->where('orders.user_id', $users->id)
                                     ->count();   
                                     
                                  if($ordmonth2==0){
                                      $ordmonth = 1;
                                  }else{
                                     $ordmonth =$ordmonth2;
                                  }
                                   if($users->count > $ordmonth2 ){
                                       $gettop = array($users);
                                       if(sizeof($gettop)<10){
                                       $i=1;
                                       
                                        if($ordmonth2==0){
                                      $difference = (($users->count/$ordmonth)*100);
                                        }else{
                                            $difference = (($users->count/$ordmonth)*100) -100;
                                        }
                                     ?>
                                <td class="text-center"><?php echo e($i); ?></td>
                                <td><?php echo e($users->name); ?><p style="font-size:14px">(<?php echo e($users->user_phone); ?>)</p></td>
                               
                               <td><?php echo e($users->count); ?></td>
                                <td><?php echo e($ordmonth2); ?></td>
                                <td><b style="color:red !important"><?php echo e($difference); ?></b> %</td>
                                
                              <?php } } ?>
                            </tr>      
                        <?php $i++; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      <?php else: ?>
                        <tr>
                          <td><?php echo e(__('keywords.No data found')); ?></td>
                        </tr>
                      <?php endif; ?>  
                    </tbody>
</table>

</div>
</div>
</div>
<div class="col-lg-6">
<div class="card">    
<div class="card-header card-header-primary">
      <h4 class="card-title "><?php echo e(__('keywords.Worst 10 Users')); ?> <?php echo e(__('keywords.Reports')); ?></h4>
     
    </div>
<div class="container"> <br> 
<table id="datatableDefaults2" class="table text-nowrap w-100">
    <thead class="thead-light">
        <tr>
            <th class="text-center">#</th>
                      <!--<th>ID</th>-->
                     <th><?php echo e(__('keywords.User')); ?></th>
                      <th><?php echo e(__('keywords.Current Month')); ?></th>
                      <th><?php echo e(__('keywords.Previous Month')); ?></th>
                      <th><?php echo e(__('keywords.Difference')); ?></th>
                     
                    </thead>
                    <tbody>
                         <?php if(count($user2)>0): ?>
                          <?php $__currentLoopData = $user2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $userss): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                
                              <?php  
             
                                 $thismonth2 =DB::table('orders')
                                         ->select('dboy_id', 'cart_id')
                                        ->whereMonth('delivery_date', date('m'))
                                         ->whereYear('delivery_date', date('Y'))
                                         ->where('payment_method','!=', NULL)
                                         ->where('order_status', 'Completed')
                                         ->where('orders.user_id', $userss->id)
                                         ->count();
                                   if($thismonth2==0){
                                       $thismonth =1;
                                   }else{
                                        $thismonth =$thismonth2;
                                   }
                                   if($userss->count > $thismonth2 ){
                                         $gettop = array($userss);
                                       if(sizeof($gettop)<10){
                                           $i=1;
                                      $difference = (($userss->count/$thismonth)*100) -100;
                                     ?>
                                <td class="text-center"><?php echo e($i); ?></td>
                                <td><?php echo e($userss->name); ?><p style="font-size:14px">(<?php echo e($userss->user_phone); ?>)</p></td>
                               
                                     
                                <td><?php echo e($thismonth2); ?></td>
                                <td><?php echo e($userss->count); ?></td>
                                <td><b style="color:red !important">-<?php echo e($difference); ?></b> %</td>
                                
                              <?php } } ?>
                            </tr>      
                        <?php $i++; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      <?php else: ?>
                        <tr>
                          <td><?php echo e(__('keywords.No data found')); ?></td>
                        </tr>
                      <?php endif; ?>  
                    </tbody>
</table>

</div>
</div>
</div>
</div>
</div>
<div>
 </div>

    <?php $__env->stopSection(); ?>
</div>
<?php echo $__env->make('admin.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u518557422/domains/themeatzheaven.online/public_html/source/resources/views/admin/d_boy/d_boy_report.blade.php ENDPATH**/ ?>