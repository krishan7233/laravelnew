
<style>
   
    .material-icons{
        margin-top:0px !important;
        margin-bottom:0px !important;
    }
</style>
<?php $__env->startSection('content'); ?>
<div class="container-fluid">
 <div class="row">
<div class="col-lg-12">
    <?php if(session()->has('success')): ?>
   <div class="alert alert-success">
    <?php if(is_array(session()->get('success'))): ?>
            <ul>
                <?php $__currentLoopData = session()->get('success'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($message); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
            <?php else: ?>
                <?php echo e(session()->get('success')); ?>

            <?php endif; ?>
        </div>
    <?php endif; ?>
     <?php if(count($errors) > 0): ?>
      <?php if($errors->any()): ?>
        <div class="alert alert-danger" role="alert">
          <?php echo e($errors->first()); ?>

          <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">×</span>
          </button>
        </div>
      <?php endif; ?>
    <?php endif; ?>
    </div>  
<div class="col-lg-12">
<div class="card">    
<div class="card-header card-header-primary">
      <h4 class="card-title "><?php echo e(__('keywords.Coupon')); ?> <?php echo e(__('keywords.List')); ?> <?php echo e($title); ?></h4>
      <a href="<?php echo e(route('coupon')); ?>" class="btn btn-primary ml-auto" style="width:10%;float:right;padding: 3px 0px 3px 0px;"><?php echo e(__('keywords.Add')); ?> <?php echo e(__('keywords.Coupon')); ?></a>
    </div>
<div class="container"><br>
<table id="datatableDefault" class="table text-nowrap w-100">
    <thead class="thead-light">
        <tr>
            <th>#</th>
            <th><?php echo e(__('keywords.Coupon Name')); ?></th>
            <th>Discount In Price</th>
                   <th>Discount In Percentage</th>
            <th><?php echo e(__('keywords.From Date')); ?></th>
            <th><?php echo e(__('keywords.To Date')); ?></th>
            <th><?php echo e(__('keywords.Uses Limit Per User')); ?></th>
            <th><?php echo e(__('keywords.Cart Value')); ?></th>
            <th class="text-center"><?php echo e(__('keywords.Actions')); ?></th>
        </tr>
    </thead>
    <tbody>
           <?php if(count($coupon)>0): ?>
          <?php $i=1; ?>
          <?php $__currentLoopData = $coupon; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cities): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td class="text-center"><?php echo e($i); ?></td>
            <td><?php echo e($cities->coupon_name); ?></td>
            <td><?php echo e($cities->amount); ?></td>
             <td><?php echo e($cities->amount_in_percentage); ?></td>
            <td><?php echo e($cities->start_date); ?></td>
            <td><?php echo e($cities->end_date); ?></td>
            <td><?php echo e($cities->uses_restriction); ?></td>
            <td><?php echo e($cities->cart_value); ?></td>

            <td class="td-actions text-center">
                <a href="<?php echo e(route('editcoupon',$cities->coupon_id)); ?>" rel="tooltip" class="btn btn-success">
                    <i class="material-icons">edit</i>
                </a>
               <a href="<?php echo e(route('deletecoupon',$cities->coupon_id)); ?>" onClick="return confirm('Are you sure you want to permanently remove this Coupon.')" rel="tooltip" class="btn btn-danger">
                    <i class="material-icons">close</i>
                </a>
            </td>
        </tr>
          <?php $i++; ?>
                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  <?php else: ?>
                    <tr>
                      <td><?php echo e(__('keywords.No data found')); ?></td>
                    </tr>
                  <?php endif; ?>
    </tbody>
</table>
</div>
</div>
</div>
</div>
</div>
<div>
    </div>

    <?php $__env->stopSection(); ?>

<?php echo $__env->make('store.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u518557422/domains/themeatzheaven.online/public_html/source/resources/views/store/coupon/couponlist.blade.php ENDPATH**/ ?>