
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/switchery/0.8.2/switchery.min.css">
<script src="https://cdnjs.cloudflare.com/ajax/libs/switchery/0.8.2/switchery.min.js"></script>


<style>
    .material-icons{
        margin-top:0px !important;
        margin-bottom:0px !important;
    }
</style>
<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    
 <div class="row">
<div class="col-lg-12">
<?php if(session()->has('success')): ?>
<div class="alert alert-success">
<?php if(is_array(session()->get('success'))): ?>
        <ul>
            <?php $__currentLoopData = session()->get('success'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($message); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
        <?php else: ?>
            <?php echo e(session()->get('success')); ?>

        <?php endif; ?>
    </div>
<?php endif; ?>
 <?php if(count($errors) > 0): ?>
  <?php if($errors->any()): ?>
    <div class="alert alert-danger" role="alert">
      <?php echo e($errors->first()); ?>

      <button type="button" class="close" data-dismiss="alert" aria-label="Close">
        <span aria-hidden="true">×</span>
      </button>
    </div>
  <?php endif; ?>
<?php endif; ?>
</div>
<div class="col-lg-12">
<div class="card">    
<div class="card-header card-header-primary">
      <h4 class="card-title "><?php echo e(__('keywords.Product')); ?> <?php echo e(__('keywords.List')); ?></h4>
      <a href="<?php echo e(route('AddProduct')); ?>" class="btn btn-primary ml-auto" style="width:15%;float:right;padding: 3px 0px 3px 0px;"><?php echo e(__('keywords.Add')); ?> <?php echo e(__('keywords.Product')); ?></a>
    </div>
<div class="container"><br>    
<table id="datatableDefault" class="table text-nowrap w-100">
    <thead class="thead-light">
        <tr>
            <th class="text-center">#</th>
            <th><?php echo e(__('keywords.Product')); ?> <?php echo e(__('keywords.Name')); ?></th>
            <th><?php echo e(__('keywords.Product Id')); ?></th>
            <th><?php echo e(__('keywords.Category')); ?></th>
            <th><?php echo e(__('keywords.Type')); ?></th>
            <th><?php echo e(__('keywords.Product')); ?> <?php echo e(__('keywords.Image')); ?></th>
            <th>Hide</th>
            <th class="text-right"><?php echo e(__('keywords.Actions')); ?></th>
        </tr>
    </thead>
    <tbody>
           <?php if(count($product)>0): ?>
          <?php $i=1; ?>
          <?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $products): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td class="text-center"><?php echo e($i); ?></td>
            <td><?php echo e($products->product_name); ?></td>
            <td><?php echo e($products->product_id); ?></td>
            <td> <?php echo e($products->title); ?></td>
             <td> <?php echo e($products->type); ?></td>
            <td><img src="<?php echo e($url_aws.$products->product_image); ?>" alt="image"  style="width:50px;height:50px; border-radius:50%"/></td>
            <td><input type="checkbox" data-id="<?php echo e($products->product_id); ?>" name="status" class="js-switch" <?php echo e($products->hide == 1 ? 'checked' : ''); ?>></td>
            <td class="td-actions text-right">
                <a href="<?php echo e(route('EditProduct',$products->product_id)); ?>" rel="tooltip" class="btn btn-success">
                    <i class="fa fa-edit"></i>
                </a>
                <a href="<?php echo e(route('varient',$products->product_id)); ?>" rel="tooltip" class="btn btn-primary">
                    <i class="fa fa-cubes"></i>
                </a>
                <a href="<?php echo e(route('DeleteProduct',$products->product_id)); ?>" onClick="return confirm('Are you sure you want to permanently remove this Product.')" rel="tooltip" class="btn btn-danger">
                    <i class="fa fa-trash"></i>
                </a>
            </td>
        </tr>
          <?php $i++; ?>
                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  <?php else: ?>
                    <tr>
                      <td><?php echo e(__('keywords.No data found')); ?></td>
                    </tr>
                  <?php endif; ?>
    </tbody>
</table>
    </div>
    </div>
    </div>
    </div>
    </div>
    <div>
    </div>
    <script>
    $(document).ready(function(){
    $('.js-switch').change(function () {
        let status = $(this).prop('checked') === true ? 1 : 0;
        let product_id = $(this).data('id');
        $.ajax({
            type: "GET",
            dataType: "json",
            url: '<?php echo e(route("hideprod")); ?>',
            data: {'status': status, 'product_id': product_id},
            success: function (data) {
                console.log(data.message);
            }
        });
    });
});
</script>
     <script>
        $(document).ready( function () {
            $('#myTable').DataTable();
        } );
    </script>
    <script>
    let elems = Array.prototype.slice.call(document.querySelectorAll('.js-switch'));

    elems.forEach(function(html) {
    let switchery = new Switchery(html,  { size: 'small' });
    });
    </script>

     
    <?php $__env->stopSection(); ?>
</div>
<?php echo $__env->make('admin.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\projectfiles\source\resources\views/admin/product/list.blade.php ENDPATH**/ ?>