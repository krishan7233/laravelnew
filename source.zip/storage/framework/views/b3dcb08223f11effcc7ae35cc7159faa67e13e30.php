
<style>
        .collo {
      overflow-y: hidden;
      overflow-x: scroll;
      -webkit-overflow-scrolling: touch;
    }


</style>
<?php $__env->startSection('content'); ?>
<div class="container-fluid">
   <div class="col-lg-12">
    <?php if(session()->has('success')): ?>
   <div class="alert alert-success">
    <?php if(is_array(session()->get('success'))): ?>
            <ul>
                <?php $__currentLoopData = session()->get('success'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($message); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
            <?php else: ?>
                <?php echo e(session()->get('success')); ?>

            <?php endif; ?>
        </div>
    <?php endif; ?>
     <?php if(count($errors) > 0): ?>
      <?php if($errors->any()): ?>
        <div class="alert alert-danger" role="alert">
          <?php echo e($errors->first()); ?>

          <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">×</span>
          </button>
        </div>
      <?php endif; ?>
    <?php endif; ?>
    </div> 
<div class="col-lg-12">
<div class="card"> 

<div class="card-header card-header-primary">
      <h4 class="card-title "><?php echo e(__('keywords.Order List (Today)')); ?></h4>
</div>
<div class="card-header card-header-secondary">
      <form class="forms-sample" action="<?php echo e(route('datewise_orders')); ?>" method="post" enctype="multipart/form-data">
                      <?php echo e(csrf_field()); ?>

            <div class="row">
                      <div class="col-md-4">
                        <div class="form-group">
                          <label style="margin-bottom: 13px;margin-top: 10px;"><?php echo e(__('keywords.Payment Method')); ?></label>
                          <select name="payment_method" class="form-control">
                              <option disabled selected><?php echo e(__('keywords.Select payment method')); ?></option>
                              <option value="all"><?php echo e(__('keywords.All')); ?></option>
                              <option value="COD"><?php echo e(__('keywords.COD')); ?></option>
                              <option value="online"><?php echo e(__('keywords.Online')); ?></option>
                              <option value="wallet"><?php echo e(__('keywords.Wallet')); ?></option>
                              
                          </select>
                        </div>
                      </div>
                       <div class="col-md-3"><br>
                        <div class="form-group">
                          <label><?php echo e(__('keywords.From Date')); ?></label><br>
                          <input type="date" name="sel_date" class="form-control">
                        </div>
                      </div>
                      <div class="col-md-3"><br>
                        <div class="form-group">
                          <label><?php echo e(__('keywords.To Date')); ?></label><br>
                          <input type="date" name="to_date" class="form-control">
                        </div>
                      </div>
                      <div class="col-md-2">
                        <div class="form-group">
                          <button type="submit"  style="margin-bottom: 13px;margin-top: 10px;" class="btn btn-primary"><?php echo e(__('keywords.Show Orders')); ?></button>
                        </div>
                      </div>
                    </div>   
            </form>
       </div><hr>
<div class="container"> <br> 
<table id="datatableDefault" class="table text-nowrap w-100">
    <thead class="thead-light">
        <tr>
            <th class="text-center">#</th>
            <th><?php echo e(__('keywords.Cart_id')); ?></th>
            <th><?php echo e(__('keywords.Cart price')); ?></th>
            <th><?php echo e(__('keywords.User')); ?></th>
            <th><?php echo e(__('keywords.Delivery_Date')); ?></th>
			<th><?php echo e(__('keywords.Delivery Boy')); ?></th>
            <th><?php echo e(__('keywords.Cart Products')); ?></th>
            <th><?php echo e(__('keywords.Payment')); ?></th>
            <th class="text-right"><?php echo e(__('keywords.Order Status')); ?></th>
            <th><?php echo e(__('keywords.Store')); ?></th>
        </tr>
    </thead>
    <tbody>
           <?php if(count($ord)>0): ?>
          <?php $i=1; ?>
          <?php $__currentLoopData = $ord; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ords): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td class="text-center"><?php echo e($i); ?></td>
            <td><?php echo e($ords->cart_id); ?></td>
            <td><?php echo e($ords->total_price); ?></td>
            <td><?php echo e($ords->user_name); ?>(<?php echo e($ords->user_phone); ?>)</td>
             <td><?php echo e($ords->delivery_date); ?></td>
			 <?php if($ords->boy_name!= NULL): ?>
             <td><?php echo e($ords->boy_name); ?><p style="font-size:14px">(<?php echo e($ords->boy_phone); ?>)</p></td>
			  <?php else: ?>
			  <td>Order Not confirmed yet</td>
              <?php endif; ?>
            <td><button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModal1<?php echo e($ords->cart_id); ?>">Details</button></td>
            <?php if($ords->payment_status == 'success' || $ords->payment_status == 'Success'): ?>
            <td><?php echo e($ords->payment_method); ?> | Paid </td>
            <?php endif; ?>
             <?php if($ords->payment_status == 'cod' || $ords->payment_status == 'COD' || $ords->payment_status == 'Cod'): ?>
            <td>Cash on Delivery</td>
            <?php endif; ?>
                <td class="td-actions text-right">
                <p style="color:green !important"><?php echo e($ords->order_status); ?></p>
            </td>
            <td class="td-actions text-right">
                <p><?php echo e($ords->store_name); ?>(<?php echo e($ords->phone_number); ?>)</p>
            </td>
        </tr>
          <?php $i++; ?>
                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  <?php else: ?>
                    <tr>
                      <td><?php echo e(__('keywords.No data found')); ?></td>
                    </tr>
                  <?php endif; ?>
    </tbody>
</table>
</div>
</div>

</div>
</div>
<div>
</div>


<!--/////////details model//////////-->
<?php $__currentLoopData = $ord; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ords): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="modal fade" id="exampleModal1<?php echo e($ords->cart_id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        	<div class="modal-dialog" role="document">
        		<div class="modal-content">
        			<div class="modal-header">
        				<h5 class="modal-title" id="exampleModalLabel"><?php echo e(__('keywords.Order Details')); ?> (<b><?php echo e($ords->cart_id); ?></b>)</h5>
        					<button type="button" class="close" data-dismiss="modal" aria-label="Close">
        						<span aria-hidden="true">&times;</span>
        					</button>
        			</div>
        			<!--//form-->
        			<table class="table table-bordered" id="example2" width="100%" cellspacing="0">
                      <thead>
                        <tr>
                        <th><?php echo e(__('keywords.product ')); ?></th>
                        <th><?php echo e(__('keywords.order qty')); ?></th>
                        <th><?php echo e(__('keywords.Price')); ?></th>
                             <?php if($ords->order_status == 'Pending'): ?> <th><?php echo e(__('keywords.Remove')); ?></th> <?php endif; ?>
                        </tr>
                      </thead>
                      
                      <tbody>
                      <?php if(count($details)>0): ?>
                                      <?php $i=1; ?>
                                      
                          <tr>             
                        <?php $__currentLoopData = $details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detailss): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <?php if($detailss->cart_id==$ords->cart_id): ?>
    		          	   
                            <td><p><img style="width:25px;height:25px; border-radius:50%" src="<?php echo e(url($detailss->varient_image)); ?>" alt="$detailss->product_name">  <?php echo e($detailss->product_name); ?>(<?php echo e($detailss->quantity); ?><?php echo e($detailss->unit); ?>)</p>
                            </td>
                            <td><?php echo e($detailss->qty); ?></td>
                            <td> 
                            <p><span style="color:grey"><?php echo e($detailss->price); ?></span></p>
                           </td>
                             <?php if($ords->order_status == 'Pending'): ?>
                           <td align="center">
                           <a href="<?php echo e(route('store_cancel_product', $detailss->store_order_id)); ?>" rel="tooltip">
                            <i class="material-icons" style="color:red">close</i>
                            </a>
                        </td> 
                         <?php endif; ?>
    		          	  <?php endif; ?>
                         </tr>
                            <?php $i++; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          <?php else: ?>
                            <tr>
                              <td><?php echo e(__('keywords.No data found')); ?></td>
                            </tr>
                                  <?php endif; ?>
                                   
                      </tbody>
                    </table>
        		
        		</div>
        	</div>
        </div>
 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php $__env->stopSection(); ?>
</div>
<?php echo $__env->make('admin.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u518557422/domains/themeatzheaven.online/public_html/source/resources/views/admin/salesreport/todaysales.blade.php ENDPATH**/ ?>