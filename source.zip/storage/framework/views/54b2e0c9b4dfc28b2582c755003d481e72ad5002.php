<?php $__env->startSection('content'); ?>
<div class="container-fluid">
          <div class="row">
            <div class="col-lg-12">
                <?php if(session()->has('success')): ?>
               <div class="alert alert-success">
                <?php if(is_array(session()->get('success'))): ?>
                        <ul>
                            <?php $__currentLoopData = session()->get('success'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($message); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                        <?php else: ?>
                            <?php echo e(session()->get('success')); ?>

                        <?php endif; ?>
                    </div>
                <?php endif; ?>
                 <?php if(count($errors) > 0): ?>
                  <?php if($errors->any()): ?>
                    <div class="alert alert-danger" role="alert">
                      <?php echo e($errors->first()); ?>

                      <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">×</span>
                      </button>
                    </div>
                  <?php endif; ?>
                <?php endif; ?>
                </div>  
            <div class="col-md-12">
              <div class="card">
                <div class="card-header card-header-primary">
                  <h4 class="card-title"><?php echo e(__('keywords.Edit')); ?> <?php echo e(__('keywords.Coupon Details')); ?></h4>
                  <form class="forms-sample" action="<?php echo e(route('updatecoupon')); ?>" method="post" enctype="multipart/form-data">
                      <?php echo e(csrf_field()); ?>

                </div>
                <div class="card-body">
                  <form>
                    <div class="row">
                      <div class="col-md-6">
                        <div class="form-group">
                          <label class="bmd-label-floating"><?php echo e(__('keywords.Coupon Name')); ?></label>
                          <input type="hidden" name="coupon_id"  value="<?php echo e($coupon->coupon_id); ?>">
                          <input type="text" value="<?php echo e($coupon->coupon_name); ?>" name="coupon_name" class="form-control">
                        </div>
                      </div>
                      <div class="col-md-6">
                        <div class="form-group">
                          <label class="bmd-label-floating"><?php echo e(__('keywords.Coupon Code')); ?></label>
                          <input type="text" value="<?php echo e($coupon->coupon_code); ?>" name="coupon_code" class="form-control">
                        </div>
                      </div>
                    </div>
                    <div class="row">
                      <div class="col-md-12">
                        <div class="form-group">
                          <label class="bmd-label-floating"><?php echo e(__('keywords.Description')); ?></label>
                          <input type="text" value="<?php echo e($coupon->coupon_description); ?>"  name="coupon_desc" class="form-control">
                        </div>
                      </div>
                    </div>
                    <div class="row">
                      <div class="col-md-4">
                        <div class="form-group">
                          <!--<label class="bmd-label-floating">Valid From</label>-->
                          <p class="card-description"><?php echo e(__('keywords.From Date')); ?></p>
                          <input type="datetime-local" value="<?php echo e($coupon->start_date); ?>" name="valid_to" class="form-control">
                        </div>
                      </div>
                      <div class="col-md-4">
                        <div class="form-group">
                          <!--<label class="bmd-label-floating">Valid To</label>-->
                          <p class="card-description"><?php echo e(__('keywords.To Date')); ?></p>
                          <input type="datetime-local" value="<?php echo e($coupon->end_date); ?>" name="valid_from" class="form-control">
                        </div>
                      </div>
                      <div class="col-md-4">
                        <div class="form-group">
                          <!--<label class="bmd-label-floating">Minimum Cart Value</label>-->
                          <p class="card-description"><?php echo e(__('keywords.Minimum Cart Value')); ?></p>
                          <input type="number" value="<?php echo e($coupon->cart_value); ?>" name="cart_value" class="form-control">
                        </div>
                      </div>
                    </div>
                    <br>
                <div class="row">
                    <div class="col-md-6">
                    <div class="form-group">
                    <label for="exampleFormControlSelect3">Discount In price</label>
               
                     <input type="text" class="form-control " id="exampleInputName1" value="<?php echo e($coupon->amount); ?>" name="coupon_discount" placeholder="Enter discount">
                    </div>
                </div>
                
                 <div class="col-md-6">
                        <div class="form-group">
                           <label for="exampleFormControlSelect3">Discount In Percentage</label>
                          <input type="text" name="discount_in_percentage" class="form-control" value="<?php echo e($coupon->amount_in_percentage); ?>" placeholder="Enter Percentage Value" required>
                        </div>
                      </div>
                  <div class="col-md-6">
                        <div class="form-group">
                           <label for="exampleFormControlSelect3">Uses Restriction</label>
                          <input type="text" name="restriction" class="form-control" value="<?php echo e($coupon->uses_restriction); ?>">
                        </div>
                      </div>
            </div>

                    <button type="submit" class="btn btn-primary pull-center">Submit</button>
                    <div class="clearfix"></div>
                  </form>
                </div>
              </div>
            </div>
			</div>
          </div>
          
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script type="text/javascript">
        	$(document).ready(function(){
        	
                $(".des_price").hide();
                
        		$(".img").on('change', function(){
        	        $(".des_price").show();
        			
        	});
        	});
</script>             
          <?php $__env->stopSection(); ?>
<?php echo $__env->make('store.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u518557422/domains/themeatzheaven.online/public_html/source/resources/views/store/coupon/couponedit.blade.php ENDPATH**/ ?>