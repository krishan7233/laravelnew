
<style>

    .material-icons{
        margin-top:0px !important;
        margin-bottom:0px !important;
    }
</style>
<?php $__env->startSection('content'); ?>
<div class="container-fluid">
 <div class="row">
<div class="col-lg-12">
<?php if(session()->has('success')): ?>
<div class="alert alert-success">
<?php if(is_array(session()->get('success'))): ?>
        <ul>
            <?php $__currentLoopData = session()->get('success'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($message); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
        <?php else: ?>
            <?php echo e(session()->get('success')); ?>

        <?php endif; ?>
    </div>
<?php endif; ?>
 <?php if(count($errors) > 0): ?>
  <?php if($errors->any()): ?>
    <div class="alert alert-danger" role="alert">
      <?php echo e($errors->first()); ?>

      <button type="button" class="close" data-dismiss="alert" aria-label="Close">
        <span aria-hidden="true">×</span>
      </button>
    </div>
  <?php endif; ?>
<?php endif; ?>
</div>
<div class="col-lg-12">
<div class="card">    
<div class="card-header card-header-primary">
      <h4 class="card-title "><?php echo e(__('keywords.Store Earnings')); ?></h4>
      <!--<p class="card-category">List Of Categories</p>-->
    </div>
<div class="container"> <br> 
<table id="datatableDefault" class="table text-nowrap w-100">
    <thead class="thead-light">
        <tr>
            <th class="text-center">#</th>
                      <!--<th>ID</th>-->
                      <th><?php echo e(__('keywords.Store')); ?></th>
                      <th><?php echo e(__('keywords.Address')); ?></th>
                      <th><?php echo e(__('keywords.Total Revenue')); ?></th>
                      <th><?php echo e(__('keywords.Already Paid')); ?></th>
                      <th><?php echo e(__('keywords.Pending Balance')); ?></th>
                    </thead>
                    <tbody>
                         <?php if(count($total_earnings)>0): ?>
                          <?php $i=1; ?>
                          <?php $__currentLoopData = $total_earnings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $total_earning): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td class="text-center"><?php echo e($i); ?></td>
                                <td><?php echo e($total_earning->store_name); ?><p style="font-size:14px">(<?php echo e($total_earning->phone_number); ?>)</p></td>
                                <td><?php echo e($total_earning->address); ?></td>
                                <td><?php echo e($total_earning->sumprice); ?></td>
                                <?php if($total_earning->paid != NULL): ?>
                                <td><?php echo e($total_earning->paid); ?></td>
                                <?php else: ?>
                                <td>0</td>
                                <?php endif; ?>
                                 <?php if($total_earning->paid != NULL): ?>
                                <td><?php echo e($total_earning->sumprice - $total_earning->paid); ?></td>
                                <?php else: ?>
                                <td><?php echo e($total_earning->sumprice); ?></td>
                                <?php endif; ?>
                            </tr>      
                        <?php $i++; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      <?php else: ?>
                        <tr>
                          <td><?php echo e(__('keywords.No data found')); ?></td>
                        </tr>
                      <?php endif; ?>  
                    </tbody>
</table>
</div>
</div>
</div>
</div>
</div>
<div>
 </div>

    <?php $__env->stopSection(); ?>
</div>
<?php echo $__env->make('admin.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u518557422/domains/themeatzheaven.online/public_html/source/resources/views/admin/store/finance.blade.php ENDPATH**/ ?>