  <div id="app" class="app app-footer-fixed">
  <div id="footer" class="app-footer">
         © <script>
              document.write(new Date().getFullYear())
            </script>, Made With <i class="fa fa-heart" style="color:red;font-size: 11px;"></i> by
             <a href="http://peytonsoft.com/" target="_blank">Peytonsoft </a>
  </div>
</div><?php /**PATH /home/softgentech/projectfiles.softgentech.com/projectfiles/source/resources/views/store/layout/footer.blade.php ENDPATH**/ ?>