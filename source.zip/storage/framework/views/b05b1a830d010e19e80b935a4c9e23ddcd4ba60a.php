
<script src="https://cdn.datatables.net/1.10.21/js/jquery.dataTables.min.js"></script>
<link rel="stylesheet" href="https://cdn.datatables.net/1.10.21/css/jquery.dataTables.min.css">

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    
 <div class="row">
<div class="col-lg-12">
    <?php if(session()->has('success')): ?>
   <div class="alert alert-success">
    <?php if(is_array(session()->get('success'))): ?>
            <ul>
                <?php $__currentLoopData = session()->get('success'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($message); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
            <?php else: ?>
                <?php echo e(session()->get('success')); ?>

            <?php endif; ?>
        </div>
    <?php endif; ?>
     <?php if(count($errors) > 0): ?>
      <?php if($errors->any()): ?>
        <div class="alert alert-danger" role="alert">
          <?php echo e($errors->first()); ?>

          <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">×</span>
          </button>
        </div>
      <?php endif; ?>
    <?php endif; ?>
    </div>
<div class="col-lg-12">
<div class="card">    
<div class="card-header card-header-primary">
      <h4 class="card-title "><?php echo e(__('keywords.App Users')); ?></h4>
    </div>
      <div class="card-header card-header-secondary">
    <form class="forms-sample" action="<?php echo e(route('daywise_reg')); ?>" method="post" enctype="multipart/form-data">
                      <?php echo e(csrf_field()); ?>

                     <div class="row">
                    
                       <div class="col-md-4"><br>
                        <div class="form-group">
                          <label><?php echo e(__('keywords.From Date')); ?></label><br>
                          <input type="date" name="sel_date" class="form-control">
                        </div>
                      </div>
                       <div class="col-md-4"><br>
                        <div class="form-group">
                          <label><?php echo e(__('keywords.To Date')); ?></label><br>
                          <input type="date" name="to_date" class="form-control">
                        </div>
                      </div>
                      <div class="col-md-4">
                        <div class="form-group">
                          <button type="submit"  style="margin-bottom: 13px;margin-top: 10px;" value="SUBMIT" class="btn btn-primary"><?php echo e(__('keywords.Show Users')); ?></button>
                        </div>
                      </div>
                    </div>  
            </form>
       </div><hr>
<div class="container"> <br> 
<table id="datatableDefault" class="table text-nowrap w-100">
    <thead class="thead-light">
        <tr>
            <th>#</th>
            <th><?php echo e(__('keywords.User')); ?> <?php echo e(__('keywords.Name')); ?></th>
            <th><?php echo e(__('keywords.User Phone')); ?></th>
            <th><?php echo e(__('keywords.User Email')); ?></th>
            <th><?php echo e(__('keywords.City/Area')); ?></th>
            <th><?php echo e(__('keywords.Registration Date')); ?></th>
            <th><?php echo e(__('keywords.Is Verified')); ?></th>
            <th><?php echo e(__('keywords.Active/Block/Delete')); ?></th>
        </tr>
    </thead>
    <tbody>
           <?php if(count($users)>0): ?>
          <?php $i=1; ?>
          <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td class="text-center"><?php echo e($i); ?></td>
            <td><?php echo e($user->name); ?></td>
            <td><?php echo e($user->user_phone); ?></td>
            <td><?php echo e($user->email); ?></td>
            <td><?php echo e($user->city_name); ?>,<?php echo e($user->society_name); ?></td>
            <td><?php echo e($user->reg_date); ?></td>
            <?php if($user->is_verified==0): ?>
            <td style="color:red"><?php echo e(__('keywords.Not Verified')); ?></td>
            <?php else: ?>
            <td style="color:green"><?php echo e(__('keywords.Verified')); ?></td>
            <?php endif; ?>
            
               
            <td class="td-actions text-right">
                 <?php if($user->block==1): ?>
               <a href="<?php echo e(route('userunblock',$user->id)); ?>" rel="tooltip" class="btn btn-danger">
                    <?php echo e(__('keywords.Blocked')); ?>

                </a>
                <?php else: ?>
                <a href="<?php echo e(route('userblock',$user->id)); ?>" rel="tooltip" class="btn btn-primary">
                   <?php echo e(__('keywords.Active')); ?>

                </a>
                <?php endif; ?>
                <a href="<?php echo e(route('ed_user',$user->id)); ?>" rel="tooltip" class="btn btn-primary">
                   <?php echo e(__('keywords.Edit')); ?> <?php echo e(__('keywords.User')); ?>

                </a>
                <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModal1<?php echo e($user->id); ?>"><?php echo e(__('keywords.Recharge')); ?></button>
                 <a href="<?php echo e(route('del_userfromlist',$user->id)); ?>" rel="tooltip" onclick="return confirm('Are You sure! It will remove all the addresses & orders related to this User.')" class="btn btn-danger">
                    <?php echo e(__('keywords.Delete')); ?>

                </a>
            </td>
        </tr>
          <?php $i++; ?>
                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  <?php else: ?>
                    <tr>
                      <td><?php echo e(__('keywords.No data found')); ?></td>
                    </tr>
                  <?php endif; ?>
    </tbody>
</table>
</div>  
</div>
</div>
</div>
</div>
<div>
      <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="modal fade" id="exampleModal1<?php echo e($user->id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
          <div class="modal-dialog" role="document">
            <div class="modal-content">
              <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel"><b><?php echo e($user->name); ?></b></h5>
                  <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                  </button>
              </div>
              <br>
              <!--//form-->
              <form class="forms-sample" action="<?php echo e(route('usr_recharge', $user->id)); ?>" method="post" enctype="multipart/form-data">
                      <?php echo e(csrf_field()); ?>

              <div class="row">
                  
                <div class="col-md-3" align="center"></div>  
                      <div class="col-md-6" align="center">
                        <div class="form-group">
                        <label><?php echo e(__('keywords.Enter Amount')); ?></label>        
                  <input class="form-control" type="number" min="10" step="0.01" value="0" step ="0.01" name="amt"/>
              </div>
              <button type="submit" class="btn btn-primary pull-center"><?php echo e(__('keywords.Submit')); ?></button>
              </div>
              </div>
                
                    <div class="clearfix"></div>
              </form>
              <!--//form-->
            </div>
          </div>
        </div>
 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
<style>.buttons-html5 {
    color: white !important;
    background-color: #35d26d !important;
    border-radius: 5px;
    margin: 2px !important;
}
.buttons-print {
    color: white !important;
    background-color: #35d26d !important;
    border-radius: 5px;
    margin: 2px !important;
}</style>
<script>
     $('#myTable').DataTable( {
    dom: 'Bfrtip',
    buttons: [
        'copy', 'excel', 'pdf'
    ]
} );
    </script>
    <?php $__env->stopSection(); ?>
</div>
<?php echo $__env->make('admin.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/softgentech/projectfiles.softgentech.com/projectfiles/source/resources/views/admin/user/list.blade.php ENDPATH**/ ?>