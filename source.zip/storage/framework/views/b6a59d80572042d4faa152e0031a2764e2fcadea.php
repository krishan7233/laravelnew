
<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    
 <div class="row">
<div class="col-lg-12">
    <?php if(session()->has('success')): ?>
   <div class="alert alert-success">
    <?php if(is_array(session()->get('success'))): ?>
            <ul>
                <?php $__currentLoopData = session()->get('success'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($message); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
            <?php else: ?>
                <?php echo e(session()->get('success')); ?>

            <?php endif; ?>
        </div>
    <?php endif; ?>
     <?php if(count($errors) > 0): ?>
      <?php if($errors->any()): ?>
        <div class="alert alert-danger" role="alert">
          <?php echo e($errors->first()); ?>

          <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">×</span>
          </button>
        </div>
      <?php endif; ?>
    <?php endif; ?>
    </div>
<div class="col-lg-12">
<div class="card">    
<div class="card-header card-header-primary">
      <h4 class="card-title "><?php echo e(__('keywords.Store')); ?> <?php echo e(__('keywords.Products')); ?> (<?php echo e(__('keywords.For Approval')); ?>)</h4>
    </div>
   
<div class="container"> <br> 
<table id="datatableDefault" class="table w-100">
    <thead class="thead-light">
        <tr>
            <th>#</th>
             <th><?php echo e(__('keywords.Image')); ?></th>
            <th><?php echo e(__('keywords.Product')); ?> <?php echo e(__('keywords.Name')); ?></th>
            <th><?php echo e(__('keywords.price')); ?></th>
            <th><?php echo e(__('keywords.MRP')); ?></th>
            <th><?php echo e(__('keywords.Store')); ?></th>
            <th class="td-actions text-right"><?php echo e(__('keywords.Approve/Reject')); ?></th>
        </tr>
    </thead>
    <tbody>
           <?php if(count($product)>0): ?>
          <?php $i=1; ?>
          <?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $products): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td class="text-center"><?php echo e($i); ?></td>
             <td><img src="<?php echo e(url($products->product_image)); ?>" alt="<?php echo e($products->product_name); ?>" style="width:50px;height:50px; border-radius:50%"></td>
            <td><?php echo e($products->product_name); ?>(<?php echo e($products->quantity); ?><?php echo e($products->unit); ?>)</td>
            <td><?php echo e($products->base_price); ?></td>
            <td><?php echo e($products->base_mrp); ?></td>
            <td><?php echo e($products->store_name); ?>(<?php echo e($products->city); ?>),<br><b><?php echo e($products->phone_number); ?></b></td>
               
            <td class="td-actions text-right">
                 <?php if($products->approved==1): ?>
               <p><b style="color:green"><?php echo e(__('keywords.Approved')); ?></b></p>
               <?php elseif($products->approved==2): ?>
               <p><b style="color:red"><?php echo e(__('keywords.Rejected')); ?></b></p>
                <?php else: ?>
                <a href="<?php echo e(route('st_p_approve',$products->varient_id)); ?>"  onclick="return confirm('Are you sure you want to approve this product ?')" rel="tooltip" class="btn btn-primary">
                  <?php echo e(__('keywords.Approve')); ?>

                </a>
                 <a href="<?php echo e(route('st_p_reject',$products->varient_id)); ?>" rel="tooltip" onclick="return confirm('Are You sure! It will be rejected ?')" class="btn btn-danger">
                   <?php echo e(__('keywords.Reject')); ?>

                </a>
                <?php endif; ?>
                
            </td>
        </tr>
          <?php $i++; ?>
                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  <?php else: ?>
                    <tr>
                      <td><?php echo e(__('keywords.No data found')); ?></td>
                    </tr>
                  <?php endif; ?>
    </tbody>
</table>
</div>  
</div>
</div>
</div>
</div>
<div>
    </div>
    <?php $__env->stopSection(); ?>
</div>
<?php echo $__env->make('admin.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/softgentech/projectfiles.softgentech.com/projectfiles/source/resources/views/admin/store_product/list.blade.php ENDPATH**/ ?>