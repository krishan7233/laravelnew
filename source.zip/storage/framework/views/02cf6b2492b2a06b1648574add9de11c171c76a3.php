
<style>
  
    .material-icons{
        margin-top:0px !important;
        margin-bottom:0px !important;
    }
</style>
<?php $__env->startSection('content'); ?>
<div class="container-fluid">
      
 <div class="row">
<div class="col-lg-12">
    <?php if(session()->has('success')): ?>
   <div class="alert alert-success">
    <?php if(is_array(session()->get('success'))): ?>
            <ul>
                <?php $__currentLoopData = session()->get('success'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($message); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
            <?php else: ?>
                <?php echo e(session()->get('success')); ?>

            <?php endif; ?>
        </div>
    <?php endif; ?>
     <?php if(count($errors) > 0): ?>
      <?php if($errors->any()): ?>
        <div class="alert alert-danger" role="alert">
          <?php echo e($errors->first()); ?>

          <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">×</span>
          </button>
        </div>
      <?php endif; ?>
    <?php endif; ?>
    </div>   
<div class="col-lg-12">
<div class="card">    
<div class="card-header card-header-primary">
      <h4 class="card-title "><?php echo e(__('keywords.Store')); ?> <?php echo e(__('keywords.List')); ?></h4>
      <a href="<?php echo e(route('store')); ?>" class="btn btn-primary ml-auto" style="width:10%;float:right;padding: 3px 0px 3px 0px;"><?php echo e(__('keywords.Add')); ?> <?php echo e(__('keywords.Store')); ?> </a>
    </div>
<div class="container"> <br> 
<table id="datatableDefault" class="table text-nowrap w-100">
    <thead class="thead-light">
        <tr>
            <th class="text-center">#</th>
                      <!--<th>ID</th>-->
                      <th><?php echo e(__('keywords.Store Name')); ?></th>
                      <th><?php echo e(__('keywords.City')); ?></th>
                      <th><?php echo e(__('keywords.Mobile')); ?></th>
                      <th><?php echo e(__('keywords.Email')); ?></th>
                      <th><?php echo e(__('keywords.Delivery time')); ?></th>
                      <th><?php echo e(__('keywords.Admin Share')); ?></th>
                      <th><?php echo e(__('keywords.orders')); ?></th>
                      <th><?php echo e(__('keywords.Store Status')); ?></th>
                      <th align="center"><?php echo e(__('keywords.Action')); ?></th>
                    </thead>
                    <tbody>
                         <?php if(count($city)>0): ?>
                          <?php $i=1; ?>
                          <?php $__currentLoopData = $city; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cities): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td class="text-center"><?php echo e($i); ?></td>
                                <td><?php echo e($cities->store_name); ?></td>
                                <td><?php echo e($cities->city); ?></td>
                                <td><?php echo e($cities->phone_number); ?></td>
                                <td><?php echo e($cities->email); ?></td>
                                <td><?php echo e($cities->store_opening_time); ?> - <?php echo e($cities->store_closing_time); ?></td>
                                <td><?php echo e($cities->admin_share); ?> %</td>
                                <td><a href="<?php echo e(route('admin_store_orders', $cities->id)); ?>" rel="tooltip">
                                <i class="fa fa-cubes" style="color:green"></i></a></td>
                                <td> <?php if($cities->store_status==1): ?>
                                   <span style="color:green"><b>Active</b></span>
                                    <?php else: ?>
                                   <span style="color:red"><b>Inactive</b></span>
                                    <?php endif; ?></td>
                                <td class="td-actions text-center">
                    
                                    <a href="<?php echo e(route('storedit', $cities->id)); ?>" button type="button" class="btn btn-success">
                                        <i class="fa fa-edit"></i>
                                    </button></a>
                                     <a href="<?php echo e(route('storedelete', $cities->id)); ?>" button type="button" class="btn btn-danger"  onClick="return confirm('Are you sure you want to permanently remove this Store.This store may have orders Please check its panel.')" rel="tooltip" >
                                        <i class="fa fa-trash"></i>
                                    </button></a>
                                 
                                    <?php if($cities->store_status==1): ?>
                                    <button type="button" class="btn btn-danger" data-toggle="modal" data-target="#exampleModal2<?php echo e($cities->id); ?>">
                                        <i class="fa fa-unlock-alt"></i>
                                    <?php echo e(__('keywords.Mark Inactive')); ?></button>
                                   
                                    <?php else: ?>
                                     <a href="<?php echo e(route('storeunhide', $cities->id)); ?>" button type="button" class="btn btn-primary"  onClick="return confirm('Are you sure you want to Active this Store.')" rel="tooltip" >
                                        <i class="fa fa-lock"></i>
                                    </button><?php echo e(__('keywords.Mark Active')); ?></a>
                                    <?php endif; ?>
                                     <a target="_blank" rel="noopener noreferrer" href="<?php echo e(route('secret-store-login', $cities->id)); ?>" style=" background-color:black" button type="button" class="btn btn-success">
                                       <i class="fa fa-user-secret"></i>
                                    </a>
                                </td>
                            </tr>      
                        <?php $i++; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      <?php else: ?>
                        <tr>
                          <td><?php echo e(__('keywords.No data found')); ?></td>
                        </tr>
                      <?php endif; ?>  
                    </tbody>
</table>
</div>
</div>
</div>
</div>
</div>
<div>
    <!--/////////reject orders///////////-->
<?php $__currentLoopData = $city; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cities): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="modal fade" id="exampleModal2<?php echo e($cities->id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        	<div class="modal-dialog" role="document">
        		<div class="modal-content">
        			<div class="modal-header">
        				<h5 class="modal-title" id="exampleModalLabel"><?php echo e(__('keywords.Mark Inactive')); ?>(<b><?php echo e($cities->store_name); ?></b>)</h5>
        					<button type="button" class="close" data-dismiss="modal" aria-label="Close">
        						<span aria-hidden="true">&times;</span>
        					</button>
        			</div>
        			<!--//form-->
        		<form class="forms-sample" action="<?php echo e(route('storehide', $cities->id)); ?>" method="post" enctype="multipart/form-data">
                      <?php echo e(csrf_field()); ?>

        			<div class="row">
        			  <div class="col-md-3" align="center"></div>  
                      <div class="col-md-6" align="center">
                          <br>
                        <div class="form-group">
                           <label><?php echo e(__('keywords.Inactive Reason')); ?></label>    
        		     	   <textarea name="cause" row="5" required></textarea>
        			    </div><br>
        			<button type="submit" class="btn btn-primary pull-center"><?php echo e(__('keywords.Submit')); ?></button>
        			</div>
        			</div>
        			  
                    <div class="clearfix"></div>
        			</form>
        		
        		</div>
        	</div>
        </div>
 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    <?php $__env->stopSection(); ?>
</div>
<?php echo $__env->make('admin.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\projectfiles\source\resources\views/admin/store/storeclist.blade.php ENDPATH**/ ?>