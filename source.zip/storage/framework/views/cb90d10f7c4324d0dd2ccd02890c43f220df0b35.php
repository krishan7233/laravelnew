
<style>
   
    .material-icons{
        margin-top:0px !important;
        margin-bottom:0px !important;
    }
</style>
<?php $__env->startSection('content'); ?>
<div class="container-fluid">
 <div class="row">
<div class="col-lg-12">
    <?php if(session()->has('success')): ?>
   <div class="alert alert-success">
    <?php if(is_array(session()->get('success'))): ?>
            <ul>
                <?php $__currentLoopData = session()->get('success'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($message); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
            <?php else: ?>
                <?php echo e(session()->get('success')); ?>

            <?php endif; ?>
        </div>
    <?php endif; ?>
     <?php if(count($errors) > 0): ?>
      <?php if($errors->any()): ?>
        <div class="alert alert-danger" role="alert">
          <?php echo e($errors->first()); ?>

          <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">×</span>
          </button>
        </div>
      <?php endif; ?>
    <?php endif; ?>
    </div>
<div class="col-lg-12">
   
<div class="card">    
<div class="card-header card-header-primary">
      <h4 class="card-title "><?php echo e(__('keywords.Stores')); ?> <?php echo e(__('keywords.Callback Requests')); ?></h4>
    </div>
<div class="container"> <br> 
<table id="datatableDefault" class="table text-nowrap w-100">
    <thead class="thead-light">
        <tr>
            <th>#</th>
            <th><?php echo e(__('keywords.ID')); ?></th>
            <th><?php echo e(__('keywords.Store Name')); ?></th>
            <th><?php echo e(__('keywords.Store Phone')); ?></th>
            <th class="text-center"><?php echo e(__('keywords.Actions')); ?></th>
        </tr>
    </thead>
    <tbody>
           <?php if(count($requests)>0): ?>
          <?php $i=1; ?>
          <?php $__currentLoopData = $requests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $request): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td class="text-center"><?php echo e($i); ?></td>
            <td><?php echo e($request->store_id); ?></td>
            <td><?php echo e($request->store_name); ?></td>
            <td><?php echo e($request->store_phone); ?></td>

            <td class="td-actions text-center">
                <?php if($request->processed == 0): ?>
                <a href="<?php echo e(route('store_callbackproc',$request->callback_req_id)); ?>" rel="tooltip" class="btn btn-success">
                    <i class="fa fa-phone"></i> &nbsp; <?php echo e(__('keywords.Process')); ?>

                </a>
                <?php else: ?>
                <span style="color:green; font-weight:bold"><?php echo e(__('keywords.Processed')); ?></span>
                <?php endif; ?>
            </td>
        </tr>
          <?php $i++; ?>
                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  <?php else: ?>
                    <tr>
                      <td><?php echo e(__('keywords.No data found')); ?></td>
                    </tr>
                  <?php endif; ?>
    </tbody>
</table>
</div>  
</div>
</div>
</div>
</div>
<div>
    </div>

    <?php $__env->stopSection(); ?>
</div>
<?php echo $__env->make('admin.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u518557422/domains/themeatzheaven.online/public_html/source/resources/views/admin/callback/store_request.blade.php ENDPATH**/ ?>