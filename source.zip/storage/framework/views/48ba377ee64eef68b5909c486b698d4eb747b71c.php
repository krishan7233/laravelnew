
<style>

    .material-icons{
        margin-top:0px !important;
        margin-bottom:0px !important;
    }
</style>
<?php $__env->startSection('content'); ?>
<div class="container-fluid">
 <div class="row">
<div class="col-lg-12">
<?php if(session()->has('success')): ?>
<div class="alert alert-success">
<?php if(is_array(session()->get('success'))): ?>
        <ul>
            <?php $__currentLoopData = session()->get('success'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($message); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
        <?php else: ?>
            <?php echo e(session()->get('success')); ?>

        <?php endif; ?>
    </div>
<?php endif; ?>
 <?php if(count($errors) > 0): ?>
  <?php if($errors->any()): ?>
    <div class="alert alert-danger" role="alert">
      <?php echo e($errors->first()); ?>

      <button type="button" class="close" data-dismiss="alert" aria-label="Close">
        <span aria-hidden="true">×</span>
      </button>
    </div>
  <?php endif; ?>
<?php endif; ?>
</div>
<div class="col-lg-12">
<div class="card">    
<div class="card-header card-header-primary">
      <h4 class="card-title "><?php echo e(__('keywords.Incentive')); ?> <?php echo e(__('keywords.Payouts')); ?></h4>
     
    </div>
<div class="container"> <br> 
<table id="datatableDefault" class="table text-nowrap w-100">
    <thead class="thead-light">
        <tr>
            <th class="text-center">#</th>
                      <!--<th>ID</th>-->
                      <th style="width:10%"><?php echo e(__('keywords.Delivery Boy')); ?></th>
                      <th style="width:15%"><?php echo e(__('keywords.Address')); ?></th>
                       <th style="width:15%"><?php echo e(__('keywords.Bank/UPI')); ?></th>
                      <th style="width:15%"><?php echo e(__('keywords.Total Incentive')); ?></th>
                      <th style="width:15%"><?php echo e(__('keywords.Paid Incentive')); ?></th>
                      <th style="width:15%"><?php echo e(__('keywords.Pending Incentive')); ?></th>
                       <th style="width:15%"><?php echo e(__('keywords.Action')); ?></th>
                    </thead>
                    <tbody>
                         <?php if(count($total_earnings)>0): ?>
                          <?php $i=1; ?>
                          <?php $__currentLoopData = $total_earnings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $total_earning): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td class="text-center"><?php echo e($i); ?></td>
                                <td><?php echo e($total_earning->boy_name); ?><p style="font-size:14px">(<?php echo e($total_earning->boy_phone); ?>)</p></td>
                                <td><?php echo e($total_earning->boy_loc); ?></td>
                                 <td><?php if($total_earning->holder_name != NULL): ?><b><?php echo e(__('keywords.A/C Holder')); ?> :</b> <?php echo e($total_earning->holder_name); ?>,<br><?php endif; ?> <?php if($total_earning->ac_no != NULL): ?><b><?php echo e(__('keywords.A/C No.')); ?> :</b><?php echo e($total_earning->ac_no); ?>,<br><?php endif; ?> <?php if($total_earning->bank_name != NULL): ?><b><?php echo e(__('keywords.Bank Name')); ?> :</b><?php echo e($total_earning->bank_name); ?>,<br><?php endif; ?> <?php if($total_earning->ifsc != NULL): ?><b><?php echo e(__('keywords.IFSC')); ?> :</b><?php echo e($total_earning->ifsc); ?>,<br><?php endif; ?>
                                 <?php if($total_earning->upi != NULL): ?><b><?php echo e(__('keywords.UPI')); ?> :</b> <?php echo e($total_earning->upi); ?><?php endif; ?></td>
                                <td><?php echo e($total_earning->earned_till_now); ?></td>
                                <td><?php echo e($total_earning->paid_till_now); ?></td>
                                <td><?php echo e($total_earning->remaining); ?></td>
                                <td class="td-actions text-center">
                                    <?php if($total_earning->remaining == 0): ?>
                                    <span style="color:green">Paid</span>
                                    <?php else: ?>
                                    <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModal1<?php echo e($total_earning->dboy_id); ?>"><?php echo e(__('keywords.Pay')); ?></button>
                                    <?php endif; ?>
                                </td>
                            </tr>      
                        <?php $i++; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      <?php else: ?>
                        <tr>
                          <td><?php echo e(__('keywords.No data found')); ?></td>
                        </tr>
                      <?php endif; ?>  
                    </tbody>
</table>

   <?php $__currentLoopData = $total_earnings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $total_earning): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="modal fade" id="exampleModal1<?php echo e($total_earning->dboy_id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        	<div class="modal-dialog" role="document">
        		<div class="modal-content">
        			<div class="modal-header">
        				<h5 class="modal-title" id="exampleModalLabel"><b><?php echo e($total_earning->boy_name); ?></b></h5>
        					<button type="button" class="close" data-dismiss="modal" aria-label="Close">
        						<span aria-hidden="true">&times;</span>
        					</button>
        			</div>
        			<br>
        			<!--//form-->
        			<form class="forms-sample" action="<?php echo e(route('incentive_pay', $total_earning->dboy_id)); ?>" method="post" enctype="multipart/form-data">
                      <?php echo e(csrf_field()); ?>

        			<div class="row">
        			    
        			  <div class="col-md-3" align="center"></div>  
                      <div class="col-md-6" align="center">
                        <div class="form-group">
                        <label><?php echo e(__('keywords.Enter Amount')); ?></label>        
        		     	<input class="form-control" type="number" min="10" step="0.01" value="<?php echo e($total_earning->remaining); ?>" step ="0.01" max="<?php echo e($total_earning->remaining); ?>"  name="amt"/>
        			</div>
        			<button type="submit" class="btn btn-primary pull-center"><?php echo e(__('keywords.Submit')); ?></button>
        			</div>
        			</div>
        			  
                    <div class="clearfix"></div>
        			</form>
        			<!--//form-->
        		</div>
        	</div>
        </div>
 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
</div>
</div>
</div>
</div>
<div>
 </div>

    <?php $__env->stopSection(); ?>
</div>
<?php echo $__env->make('admin.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\projectfiles\source\resources\views/admin/d_boy/finance.blade.php ENDPATH**/ ?>