<?php $__env->startSection('content'); ?>
<div class="container-fluid">
          <div class="row">
           <div class="col-lg-12">
                <?php if(session()->has('success')): ?>
               <div class="alert alert-success">
                <?php if(is_array(session()->get('success'))): ?>
                        <ul>
                            <?php $__currentLoopData = session()->get('success'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($message); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                        <?php else: ?>
                            <?php echo e(session()->get('success')); ?>

                        <?php endif; ?>
                    </div>
                <?php endif; ?>
                 <?php if(count($errors) > 0): ?>
                  <?php if($errors->any()): ?>
                    <div class="alert alert-danger" role="alert">
                      <?php echo e($errors->first()); ?>

                      <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">×</span>
                      </button>
                    </div>
                  <?php endif; ?>
                <?php endif; ?>
                </div>          
             <br>
            <div class="col-md-12">
              <div class="card">
                <div class="card-header card-header-primary">
                  <h4 class="card-title"><?php echo e(__('keywords.Edit Profile')); ?></h4>
                  <p class="card-category"><?php echo e(__('keywords.Edit your profile')); ?></p>
                </div>
                <div class="card-body">
                  <form action="<?php echo e(route('updateprof',$admin->id)); ?>" method="post" enctype="multipart/form-data">
                      <?php echo e(csrf_field()); ?>

                    <div class="row">
                      <div class="col-md-6">
                        <div class="form-group">
                          <label class="bmd-label-floating"><?php echo e(__('keywords.Admin Name')); ?></label>
                          <input type="text" name="admin_name" value="<?php echo e($admin->name); ?>" class="form-control">
                        </div>
                      </div>
                      <div class="col-md-6">
                        <div class="form-group">
                          <label class="bmd-label-floating"><?php echo e(__('keywords.Admin Email')); ?></label>
                          <input type="text" name="admin_email" value="<?php echo e($admin->email); ?>" class="form-control">
                        </div>
                      </div>
                    </div>
                    <div class="row">
                     <div class="col-md-12">
                        <img src="<?php echo e(url($admin->admin_image)); ?>" style="width:100px;height:100px;border-radius:50%;" alt="admin_image" name="old_admin_image"/>
                        
                     </div>
                      <div class="col-md-12">
                        <div class="custom-file">
                          <input type="file" name="admin_image" class="custom-file-input" id="customFile" accept="image/*"/>
                          <label class="custom-file-label" for="customFile"><?php echo e(__('keywords.Choose Admin profile')); ?></label>
                        </div>
                      </div>
                    </div><br><br>
                    <button type="submit" class="btn btn-primary pull-right"><?php echo e(__('keywords.Update Profile')); ?></button>
                    <div class="clearfix"></div>
                  </form>
                </div>
              </div>
            </div>
			</div>
          </div>
<?php $__env->stopSection(); ?>          
<?php echo $__env->make('admin.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/softgentech/projectfiles.softgentech.com/projectfiles/source/resources/views/admin/profile/profile.blade.php ENDPATH**/ ?>