

<style>
  
    .material-icons{
        margin-top:0px !important;
        margin-bottom:0px !important;
    }
</style>
<?php $__env->startSection('content'); ?>
<div class="container-fluid">
      
 <div class="row">
<div class="col-lg-12">
    <?php if(session()->has('success')): ?>
   <div class="alert alert-success">
    <?php if(is_array(session()->get('success'))): ?>
            <ul>
                <?php $__currentLoopData = session()->get('success'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($message); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
            <?php else: ?>
                <?php echo e(session()->get('success')); ?>

            <?php endif; ?>
        </div>
    <?php endif; ?>
     <?php if(count($errors) > 0): ?>
      <?php if($errors->any()): ?>
        <div class="alert alert-danger" role="alert">
          <?php echo e($errors->first()); ?>

          <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">×</span>
          </button>
        </div>
      <?php endif; ?>
    <?php endif; ?>
    </div>   
<div class="col-lg-12">
<div class="card">    
<div class="card-header card-header-primary">
      <h4 class="card-title ">Store Records</h4>
     
    </div>
<div class="container"> <br> 
<table id="datatableDefault" class="table text-nowrap w-100"> 
    <thead class="thead-light">
        <tr>
            <th class="text-center">#</th>
                      <!--<th>ID</th>-->
                      <th>Store Name</th>
                      <th>Item</th>
                      <th>Quantity</th>
                      <th>Units</th>
                      <th>Price</th>
                      <th>Date</th>
                
                    </thead>
                    <tbody>
                         <?php if(count($product)>0): ?>
                          <?php $i=1; ?>
                          <?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td class="text-center"><?php echo e($i); ?></td>
                                <td><?php echo e($value->store_name); ?></td>
                                <td><?php echo e($value->product_name); ?></td>
                                <td><?php echo e($value->productquantity.$value->unit); ?></td>
                                <td><?php echo e($value->qty); ?></td>
                                <td><?php echo e($value->price); ?></td>
                                <td><?php echo e($current_timestamp); ?></td>
                                
                            </tr>      
                        <?php $i++; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      <?php else: ?>
                        <tr>
                          <td><?php echo e(__('keywords.No data found')); ?></td>
                        </tr>
                      <?php endif; ?>  
                    </tbody>
</table>
</div>
</div>
</div>
</div>
</div>
<div>

    </div>

    <?php $__env->stopSection(); ?>
</div>
<?php echo $__env->make('admin.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/softgentech/projectfiles.softgentech.com/projectfiles/source/resources/views/admin/store/vendorrecords.blade.php ENDPATH**/ ?>