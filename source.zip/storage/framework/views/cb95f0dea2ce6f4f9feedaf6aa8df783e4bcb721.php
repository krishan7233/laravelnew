  <div id="app" class="app app-footer-fixed">
  <div id="footer" class="app-footer">
         © <script>
              document.write(new Date().getFullYear())
            </script>, made with <i class="fa fa-heart" style="color:red;font-size: 11px;"></i> by
             <a href="http://tecmanic.com/" target="_blank">Tecmanic </a>(VERSION - 1.6.12)
  </div>
</div><?php /**PATH C:\xampp\htdocs\grocery8\GogrocerNewPackage21June\Backend&doc\gogrocerbackend\source\resources\views/admin/layout/footer.blade.php ENDPATH**/ ?>