
<style>
    .material-icons{
        margin-top:0px !important;
        margin-bottom:0px !important;
    }
</style>
<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    
 <div class="row">
<div class="col-lg-12">
<?php if(session()->has('success')): ?>
<div class="alert alert-success">
<?php if(is_array(session()->get('success'))): ?>
        <ul>
            <?php $__currentLoopData = session()->get('success'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($message); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
        <?php else: ?>
            <?php echo e(session()->get('success')); ?>

        <?php endif; ?>
    </div>
<?php endif; ?>
 <?php if(count($errors) > 0): ?>
  <?php if($errors->any()): ?>
    <div class="alert alert-danger" role="alert">
      <?php echo e($errors->first()); ?>

      <button type="button" class="close" data-dismiss="alert" aria-label="Close">
        <span aria-hidden="true">×</span>
      </button>
    </div>
  <?php endif; ?>
<?php endif; ?>
</div>

<div class="col-lg-12">
<div class="card">    
<div class="card-header card-header-primary">
      <h4 class="card-title "><?php echo e(__('keywords.Deal Products')); ?></h4>
       <a href="<?php echo e(route('AddDeal')); ?>" class="btn btn-primary ml-auto" style="float:right !important"><?php echo e(__('keywords.Add')); ?></a>
    </div>
<div class="container"><br>    
<table id="datatableDefault" class="table text-nowrap w-100">
    <thead class="thead-light">
        <tr>
            <th class="text-center">#</th>
            <th><?php echo e(__('keywords.Product')); ?> <?php echo e(__('keywords.Name')); ?></th>
            <th><?php echo e(__('keywords.Deal Price')); ?></th>
            <th><?php echo e(__('keywords.From Date')); ?></th>
            <th><?php echo e(__('keywords.To Date')); ?></th>
            <th><?php echo e(__('keywords.Status')); ?></th>
            <th class="text-right"><?php echo e(__('keywords.Actions')); ?></th>
        </tr>
    </thead>
    <tbody>
           <?php if(count($deal_p)>0): ?>
          <?php $i=1; ?>
          <?php $__currentLoopData = $deal_p; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $deal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td class="text-center"><?php echo e($i); ?></td>
            <td><?php echo e($deal->product_name); ?> (<?php echo e($deal->quantity); ?><?php echo e($deal->unit); ?>)</td>
            <td><?php echo e($deal->deal_price); ?></td>
            <td><?php echo e($deal->valid_from); ?></td>
            <td><?php echo e($deal->valid_to); ?></td>
            <?php if($deal->valid_to > $currentdate && $currentdate >= $deal->valid_from): ?>
            <td style="color:green">Ongoing</td>
            <?php endif; ?>
            <?php if($deal->valid_to < $currentdate): ?>
            <td style="color:red">Expired</td>
            <?php endif; ?>
            <?php if($deal->valid_from > $currentdate): ?>
            <td style="color:blue">Coming soon</td>
            <?php endif; ?>
          
            
            <td class="td-actions text-right">
                <a href="<?php echo e(route('EditDeal',$deal->deal_id)); ?>" rel="tooltip" class="btn btn-success">
                    <i class="material-icons">edit</i>
                </a>
               <a href="<?php echo e(route('DeleteDeal',$deal->deal_id)); ?>" onClick="return confirm('Are you sure you want to remove this Deal Product.')" rel="tooltip" class="btn btn-danger">
                    <i class="material-icons">close</i>
                </a>
            </td>
        </tr>
          <?php $i++; ?>
                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  <?php else: ?>
                    <tr>
                      <td>No data found</td>
                    </tr>
                  <?php endif; ?>
    </tbody>
</table>
</div>
</div>
</div>
</div>
</div>
<div>
    </div>
    <?php $__env->stopSection(); ?>
</div>
<?php echo $__env->make('store.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u518557422/domains/themeatzheaven.online/public_html/source/resources/views/store/deal_product/list.blade.php ENDPATH**/ ?>