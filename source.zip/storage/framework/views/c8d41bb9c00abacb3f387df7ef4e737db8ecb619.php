
<style>
   
    .material-icons{
        margin-top:0px !important;
        margin-bottom:0px !important;
    }
</style>
<?php $__env->startSection('content'); ?>
<div class="container-fluid">
 <div class="row">
<div class="col-lg-12">
    <?php if(session()->has('success')): ?>
   <div class="alert alert-success">
    <?php if(is_array(session()->get('success'))): ?>
            <ul>
                <?php $__currentLoopData = session()->get('success'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($message); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
            <?php else: ?>
                <?php echo e(session()->get('success')); ?>

            <?php endif; ?>
        </div>
    <?php endif; ?>
     <?php if(count($errors) > 0): ?>
      <?php if($errors->any()): ?>
        <div class="alert alert-danger" role="alert">
          <?php echo e($errors->first()); ?>

          <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">×</span>
          </button>
        </div>
      <?php endif; ?>
    <?php endif; ?>
    </div>
<div class="col-lg-12">
<div class="card">    
<div class="card-header card-header-primary">
      <h4 class="card-title "><?php echo e(__('keywords.Store Payout Request')); ?></h4>
    </div>
<div class="container"> <br> 
<table id="datatableDefault" class="table text-nowrap w-100">
    <thead class="thead-light">
        <tr>
            <th class="text-center">#</th>
                      <!--<th>ID</th>-->
                      <th><?php echo e(__('keywords.Store')); ?></th>
                      <th><?php echo e(__('keywords.Address')); ?></th>
                      <th><?php echo e(__('keywords.Total Revenue')); ?></th>
                      <th><?php echo e(__('keywords.Bank Account Details')); ?></th>
                      <th><?php echo e(__('keywords.Already Paid')); ?></th>
                      <th><?php echo e(__('keywords.Pending Balance')); ?></th>
                      <th><?php echo e(__('keywords.Amount')); ?></th>
                      <th><?php echo e(__('keywords.Action')); ?></th>
                    </thead>
                    <tbody>
                         <?php if(count($total_earnings)>0): ?>
                          <?php $i=1; ?>
                          <?php $__currentLoopData = $total_earnings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $total_earning): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td class="text-center"><?php echo e($i); ?></td>
                                <td><?php echo e($total_earning->store_name); ?> <p style="font-size:14px">(<?php echo e($total_earning->phone_number); ?>)</p></td>
                                <td><?php echo e($total_earning->address); ?></td>
                                <td><?php echo e($total_earning->sumprice); ?></td>
                                <td style="font-size:10px !important"><b>Bank- </b><?php echo e($total_earning->bank_name); ?><br>
                                <b>Ac Holder- </b><?php echo e($total_earning->holder_name); ?><br>
                                <b>Ac No.- </b><?php echo e($total_earning->ac_no); ?><br>
                                <b>IFSC- </b><?php echo e($total_earning->ifsc); ?><br>
                                UPI - <?php echo e($total_earning->upi); ?></td>
                                <?php if($total_earning->paid != NULL): ?>
                                <td><?php echo e($total_earning->paid); ?></td>
                                <?php else: ?>
                                <td>0</td>
                                <?php endif; ?>
                                 <?php if($total_earning->paid != NULL): ?>
                                <td><?php echo e($total_earning->sumprice - $total_earning->paid); ?></td>
                                <?php else: ?>
                                <td><?php echo e($total_earning->sumprice); ?></td>
                                <?php endif; ?>
                                
                                <td><?php echo e($total_earning->payout_amt); ?></td>
                                <td class="td-actions text-center">
                                    <?php if($total_earning->sumprice <= $total_earning->paid ): ?>
                                    <span style="color:green">Paid</span>
                                    <?php else: ?>
                                    <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModal1<?php echo e($total_earning->id); ?>"><?php echo e(__('keywords.Pay')); ?></button>
                                    <?php endif; ?>
                                </td>
                            </tr>      
                        <?php $i++; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      <?php else: ?>
                        <tr>
                          <td><?php echo e(__('keywords.No data found')); ?></td>
                        </tr>
                      <?php endif; ?>  
                    </tbody>
</table>
</div>
</div>
</div>
</div>
</div>
<div>
  </div>
    <?php $__currentLoopData = $total_earnings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $total_earning): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="modal fade" id="exampleModal1<?php echo e($total_earning->id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
          <div class="modal-dialog" role="document">
            <div class="modal-content">
              <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel"><b><?php echo e($total_earning->store_name); ?></b></h5>
                  <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                  </button>
              </div>
              <br>
              <!--//form-->
              <form class="forms-sample" action="<?php echo e(route('com_payout', $total_earning->req_id)); ?>" method="post" enctype="multipart/form-data">
                      <?php echo e(csrf_field()); ?>

              <div class="row">
                  
                <div class="col-md-3" align="center"></div>  
                      <div class="col-md-6" align="center">
                        <div class="form-group">
                        <label><?php echo e(__('keywords.Enter Amount')); ?></label>        
                  <input class="form-control" type="number" min="10" step="0.01" value="<?php echo e($total_earning->payout_amt); ?>" step ="0.01" <?php if($total_earning->paid != NULL): ?>
                                max="<?php echo e($total_earning->sumprice - $total_earning->paid); ?>"
                                <?php else: ?>
                                max="<?php echo e($total_earning->sumprice); ?>"
                                <?php endif; ?>  name="amt"/>
              </div>
              <button type="submit" class="btn btn-primary pull-center"><?php echo e(__('keywords.Submit')); ?></button>
              </div>
              </div>
                
                    <div class="clearfix"></div>
              </form>
              <!--//form-->
            </div>
          </div>
        </div>
 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <?php $__env->stopSection(); ?>
</div>
<?php echo $__env->make('admin.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u518557422/domains/themeatzheaven.online/public_html/source/resources/views/admin/store/payoutRequest.blade.php ENDPATH**/ ?>