	<link href="<?php echo e(url('assets/select/styles/multiselect.css')); ?>" rel="stylesheet"/>
	<script src="<?php echo e(url('assets/select/scripts/multiselect.min.js')); ?>"></script>
	<style>
		/* example of setting the width for multiselect */
		#testSelect1_multiSelect {
			width: 100%;
		}
		.multiselect-wrapper .multiselect-list {
    padding: 5px;
    min-width: 91%;
}
	</style>

<?php $__env->startSection('content'); ?>
 <div class="container-fluid">
          <div class="row">
             <div class="col-lg-12">
                <?php if(session()->has('success')): ?>
               <div class="alert alert-success">
                <?php if(is_array(session()->get('success'))): ?>
                        <ul>
                            <?php $__currentLoopData = session()->get('success'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($message); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                        <?php else: ?>
                            <?php echo e(session()->get('success')); ?>

                        <?php endif; ?>
                    </div>
                <?php endif; ?>
                 <?php if(count($errors) > 0): ?>
                  <?php if($errors->any()): ?>
                    <div class="alert alert-danger" role="alert">
                      <?php echo e($errors->first()); ?>

                      <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">×</span>
                      </button>
                    </div>
                  <?php endif; ?>
                <?php endif; ?>
                </div> 
            <div class="col-md-12">
          
               <div class="card">
                <div class="card-header card-header-primary">
                  <h4 class="card-title"><?php echo e(__('keywords.Notification to Store')); ?></h4>
                  <form class="forms-sample" action="<?php echo e(route('adminNotificationSendtostore')); ?>" method="post" enctype="multipart/form-data">
                      <?php echo e(csrf_field()); ?>

                </div>
                <div class="card-body">
                     <div class="row">
                      <div class="col-md-12">
                        <div class="form-group">
                          <label class="bmd-label-floating"><?php echo e(__('keywords.Select Stores')); ?></label><br>
                          <select id='testSelect1' name="st[]"  class="form-control" multiple>
                              
                             <?php $__currentLoopData = $store; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $stores): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <option value="<?php echo e($stores->id); ?>"><?php echo e($stores->store_name); ?>(<?php echo e($stores->city); ?>)</option>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                      </div>
                       <div class="col-md-12">
                        <div class="form-group">
                          <label><?php echo e(__('keywords.Title')); ?></label>
                          <input type="text" name="notification_title" class="form-control">
                        </div>
                      </div>
                      
                       <div class="col-md-12">
                        <div class="form-group">
                          <label><?php echo e(__('keywords.Message')); ?></label>
                          <textarea name="notification_text" class="form-control"></textarea>
                        </div>
                      </div>
                      <div class="col-md-12">
                        <div>
                          <label><?php echo e(__('keywords.Image')); ?></label>
                          <input type="file" name="notify_image" class="form-control">
                        </div>
                      </div>
                    </div><br>
                    
                    <button type="submit" class="btn btn-primary pull-center"><?php echo e(__('keywords.Send Notification to Store')); ?></button>
                    <div class="clearfix"></div>
                  </form>
                </div>
              </div>
            </div>
			</div>
          </div>
          <script>
	document.multiselect('#testSelect1')
		.setCheckBoxClick("checkboxAll", function(target, args) {
			console.log("Checkbox 'Select All' was clicked and got value ", args.checked);
		})
		.setCheckBoxClick("1", function(target, args) {
			console.log("Checkbox for item with value '1' was clicked and got value ", args.checked);
		});

	function enable() {
		document.multiselect('#testSelect1').setIsEnabled(true);
	}

	function disable() {
		document.multiselect('#testSelect1').setIsEnabled(false);
	}
</script>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('admin.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u518557422/domains/themeatzheaven.online/public_html/source/resources/views/admin/settings/notification.blade.php ENDPATH**/ ?>