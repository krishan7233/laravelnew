<?php $__env->startSection('content'); ?>
 <div class="container-fluid">
          <div class="row">
             <div class="col-lg-12">
                <?php if(session()->has('success')): ?>
               <div class="alert alert-success">
                <?php if(is_array(session()->get('success'))): ?>
                        <ul>
                            <?php $__currentLoopData = session()->get('success'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($message); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                        <?php else: ?>
                            <?php echo e(session()->get('success')); ?>

                        <?php endif; ?>
                    </div>
                <?php endif; ?>
                 <?php if(count($errors) > 0): ?>
                  <?php if($errors->any()): ?>
                    <div class="alert alert-danger" role="alert">
                      <?php echo e($errors->first()); ?>

                      <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">×</span>
                      </button>
                    </div>
                  <?php endif; ?>
                <?php endif; ?>
                </div> 
            <div class="col-md-12">
              <div class="card">
                <div class="card-header card-header-primary">
                  <h4 class="card-title"><?php echo e(__('keywords.Add')); ?> <?php echo e(__('keywords.Deal Product')); ?></h4>
                  <form class="forms-sample" action="<?php echo e(route('UpdateDeal', $deal_p->deal_id)); ?>" method="post" enctype="multipart/form-data">
                      <?php echo e(csrf_field()); ?>

                </div>
                <div class="card-body">
 
                     <div class="row">
                      <div class="col-md-6">
                        <div class="form-group">
                          <label class="bmd-label-floating"><?php echo e(__('keywords.Select')); ?> <?php echo e(__('keywords.Product')); ?></label>
                          <select name="varient_id" class="form-control">
                              <option disabled selected>Select Product</option>
                              <?php $__currentLoopData = $deal; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $deals): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        		          	<option value="<?php echo e($deals->varient_id); ?>" <?php if( $deals->varient_id == $deal_p->varient_id): ?> selected <?php endif; ?>><?php echo e($deals->product_name); ?> (<?php echo e($deals->quantity); ?><?php echo e($deals->unit); ?>)</option>
        		              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                              
                          </select>
                        </div>
                      </div>

                    </div>

 
                     <div class="row">
                      <div class="col-md-6">
                        <div class="form-group">
                          <label class="bmd-label-floating"><?php echo e(__('keywords.Deal Price')); ?></label>
                          <input type="text" name="deal_price" value="<?php echo e($deal_p->deal_price); ?>" class="form-control">
                        </div>
                      </div>

                    </div>
                    
                     <div class="row">
                      <div class="col-md-6">
                        <div class="form-group">
                          <label class="bmd-label"><?php echo e(__('keywords.From Date')); ?></label><br>
                          <input type="datetime-local" name="valid_from"  value="<?php echo e($deal_p->valid_from); ?>" class="form-control">
                        </div>
                      </div>

                    </div>
                    <div class="row">
                      <div class="col-md-6">
                        <div class="form-group">
                          <label class="bmd-label"><?php echo e(__('keywords.To Date')); ?></label><br>
                          <input type="datetime-local" name="valid_to" value="<?php echo e($deal_p->valid_to); ?>"  class="form-control">
                        </div>
                      </div>

                    </div>


                    <button type="submit" class="btn btn-primary pull-center"><?php echo e(__('keywords.Submit')); ?></button>
                    <a href="<?php echo e(route('deallist')); ?>" class="btn"><?php echo e(__('keywords.Close')); ?></a>
                    <div class="clearfix"></div>
                  </form>
                </div>
              </div>
            </div>
			</div>
          </div>
<?php $__env->stopSection(); ?>





<?php echo $__env->make('store.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u518557422/domains/themeatzheaven.online/public_html/source/resources/views/store/deal_product/edit.blade.php ENDPATH**/ ?>