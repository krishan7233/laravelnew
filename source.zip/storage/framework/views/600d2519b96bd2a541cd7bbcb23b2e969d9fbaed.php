
<style>
    
    .material-icons{
        margin-top:0px !important;
        margin-bottom:0px !important;
    }
</style>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    
 <div class="row">
<div class="col-lg-12">
    <?php if(session()->has('success')): ?>
   <div class="alert alert-success">
    <?php if(is_array(session()->get('success'))): ?>
            <ul>
                <?php $__currentLoopData = session()->get('success'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($message); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
            <?php else: ?>
                <?php echo e(session()->get('success')); ?>

            <?php endif; ?>
        </div>
    <?php endif; ?>
     <?php if(count($errors) > 0): ?>
      <?php if($errors->any()): ?>
        <div class="alert alert-danger" role="alert">
          <?php echo e($errors->first()); ?>

          <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">×</span>
          </button>
        </div>
      <?php endif; ?>
    <?php endif; ?>
    </div>
    <div class="col-lg-12">  
    
    <br>
   </div> 
<div class="col-lg-12">
<div class="card">    
<div class="card-header card-header-primary">
      <h4 class="card-title "><?php echo e(__('keywords.Sub Category')); ?> <?php echo e(__('keywords.List')); ?></h4>
       <a href="<?php echo e(route('AddsubCategory')); ?>" class="btn btn-primary ml-auto" style="width:8%;float:right;padding: 3px 0px 3px 0px;"><?php echo e(__('keywords.Add')); ?></a>
    </div>
<div class="container"> <br>     
<table id="datatableDefault" class="table text-nowrap w-100">
    <thead class="thead-light">
        <tr>
            <th class="text-center">#</th>
            <th><?php echo e(__('keywords.Title')); ?></th>
            <th><?php echo e(__('keywords.Parent Category')); ?></th>
            <th><?php echo e(__('keywords.Category image')); ?></th>
            <th><?php echo e(__('keywords.Cat Id')); ?></th>
            <th class="text-right"><?php echo e(__('keywords.Actions')); ?></th>
        </tr>
    </thead>
    <tbody>
           <?php if(count($category)>0): ?>
          <?php $i=1; ?>
          <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td class="text-center"><?php echo e($i); ?></td>
            <td><?php echo e($cat->title); ?></td>
            <?php if($cat->parent == 0): ?>
            <td>-------</td>
            <?php endif; ?>
            <?php if($cat->parent != 0): ?>
            <td><?php echo e($cat->tttt); ?></td>
            <?php endif; ?>
            <td><img src="<?php echo e($url_aws.$cat->image); ?>" alt="category image" style="width:50px; height:50px; border-radius:50%;"/></td>
            <td><?php echo e($cat->cat_id); ?></td>
            <td class="td-actions text-right">
                <a href="<?php echo e(route('EditsubCategory',$cat->cat_id)); ?>" rel="tooltip" class="btn btn-success">
                    <i class="fa fa-edit"></i>
                </a>
               <a href="<?php echo e(route('DeleteCategory',$cat->cat_id)); ?>" onClick="return confirm('Are you sure you want to permanently remove this Category.')" rel="tooltip" class="btn btn-danger">
                    <i class="fa fa-trash"></i>
                </a>
            </td>
        </tr>
          <?php $i++; ?>
                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  <?php else: ?>
                    <tr>
                      <td><?php echo e(__('keywords.No data found')); ?></td>
                    </tr>
                  <?php endif; ?>
    </tbody>
</table>
</div>
</div>
</div>
</div>
</div>
<div>
</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u518557422/domains/themeatzheaven.online/public_html/source/resources/views/admin/category/sub/index.blade.php ENDPATH**/ ?>