
<style>
  
    .material-icons{
        margin-top:0px !important;
        margin-bottom:0px !important;
    }
</style>
<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    
 <div class="row">
<div class="col-lg-12">
    <?php if(session()->has('success')): ?>
   <div class="alert alert-success">
    <?php if(is_array(session()->get('success'))): ?>
            <ul>
                <?php $__currentLoopData = session()->get('success'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($message); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
            <?php else: ?>
                <?php echo e(session()->get('success')); ?>

            <?php endif; ?>
        </div>
    <?php endif; ?>
     <?php if(count($errors) > 0): ?>
      <?php if($errors->any()): ?>
        <div class="alert alert-danger" role="alert">
          <?php echo e($errors->first()); ?>

          <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">×</span>
          </button>
        </div>
      <?php endif; ?>
    <?php endif; ?>
    </div>
<div class="col-lg-12">  
     <a href="<?php echo e(route('AddD_boy')); ?>" class="btn btn-primary ml-auto" style="width:15%;float:right;padding: 3px 0px 3px 0px;"><?php echo e(__('keywords.Add')); ?> <?php echo e(__('keywords.Delivery Boy')); ?></a>
</div> 
<div class="col-lg-12">
<div class="card">    
<div class="card-header card-header-primary">
      <h4 class="card-title" style="width:50%;float:left;"><?php echo e(__('keywords.Delivery Boy')); ?> <?php echo e(__('keywords.List')); ?></h4>
    </div>
    
<div class="container"><br> 
<table id="datatableDefault" class="table text-nowrap w-100">
    <thead class="thead-light">
        <tr>
            <th> # </th>
            <th><?php echo e(__('keywords.Boy Name')); ?></th>
            <th><?php echo e(__('keywords.Boy Phone')); ?></th>
            <th><?php echo e(__('keywords.Boy Password')); ?></th>
            <th><?php echo e(__('keywords.Status')); ?></th>
            <th><?php echo e(__('keywords.Orders')); ?></th>
            <th class="text-right"><?php echo e(__('keywords.Actions')); ?></th>
        </tr>
    </thead>
    <tbody>
           <?php if(count($d_boy)>0): ?>
          <?php $i=1; ?>
          <?php $__currentLoopData = $d_boy; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d_boys): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td class="text-center"><?php echo e($i); ?></td>
            <td><?php echo e($d_boys->boy_name); ?></td>
           
            <td><?php echo e($d_boys->boy_phone); ?></td>
       
            <td><?php echo e($d_boys->password); ?></td>
            <?php if($d_boys->status == 1): ?>
            <td><p style="color:green">on duty</p></td>
            <?php else: ?>
            <td><p style="color:red">off duty</p></td>
            <?php endif; ?>
            <td><a href="<?php echo e(route('admin_dboy_orders',$d_boys->dboy_id)); ?>" rel="tooltip" class="btn btn-primary">
                    <i class="fa fa-cubes"></i></td>
            <td class="td-actions text-right">
                <a href="<?php echo e(route('EditD_boy',$d_boys->dboy_id)); ?>" rel="tooltip" class="btn btn-success">
                    <i class="fa fa-edit"></i>
                </a>
               <a href="<?php echo e(route('DeleteD_boy',$d_boys->dboy_id)); ?>" onClick="return confirm('Are you sure you want to permanently remove this Store.')" rel="tooltip" class="btn btn-danger">
                    <i class="fa fa-trash"></i>
                </a>
            </td>
        </tr>
          <?php $i++; ?>
                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  <?php else: ?>
                    <tr>
                      <td><?php echo e(__('keywords.No data found')); ?>s</td>
                    </tr>
                  <?php endif; ?>
    </tbody>
</table>
</div>
</div>
</div>
</div>
</div>
<div>
    </div>

    <?php $__env->stopSection(); ?>
</div>
<?php echo $__env->make('admin.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u518557422/domains/themeatzheaven.online/public_html/source/resources/views/admin/d_boy/list.blade.php ENDPATH**/ ?>