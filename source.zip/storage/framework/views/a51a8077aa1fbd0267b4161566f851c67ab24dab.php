
<style>
    .material-icons{
        margin-top:0px !important;
        margin-bottom:0px !important;
    }
</style>
<?php $__env->startSection('content'); ?>
<div class="container-fluid">
 <div class="row">
<div class="col-lg-12">
    <?php if(session()->has('success')): ?>
   <div class="alert alert-success">
    <?php if(is_array(session()->get('success'))): ?>
            <ul>
                <?php $__currentLoopData = session()->get('success'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($message); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
            <?php else: ?>
                <?php echo e(session()->get('success')); ?>

            <?php endif; ?>
        </div>
    <?php endif; ?>
     <?php if(count($errors) > 0): ?>
      <?php if($errors->any()): ?>
        <div class="alert alert-danger" role="alert">
          <?php echo e($errors->first()); ?>

          <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">×</span>
          </button>
        </div>
      <?php endif; ?>
    <?php endif; ?>
    </div>
<div class="col-lg-12">
<div class="card">    
<div class="card-header card-header-primary">
      <h4 class="card-title "><?php echo e(__('keywords.Varient')); ?> <?php echo e(__('keywords.List')); ?></h4>
       <a href="<?php echo e(route('storeadd-varient', $id)); ?>" class="btn btn-primary ml-auto" style="width:12%;float:right;padding: 3px 0px 3px 0px;"><?php echo e(__('keywords.Add')); ?> <?php echo e(__('keywords.Varient')); ?></a>
    </div>
<div class="container"><br>    
<table id="datatableDefault" class="table text-nowrap w-100">
    <thead class="thead-light">
        <tr>
            <th class="text-center">#</th>
            <th><?php echo e(__('keywords.Quantity')); ?></th>
            <th><?php echo e(__('keywords.Unit')); ?></th>
            <th><?php echo e(__('keywords.Description')); ?></th>
            <th class="text-right"><?php echo e(__('keywords.Actions')); ?>/<?php echo e(__('keywords.Status')); ?></th>
        </tr>
    </thead>
    <tbody>
           <?php if(count($product)>0): ?>
          <?php $i=1; ?>
          <?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $products): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td class="text-center"><?php echo e($i); ?></td>
            <td><?php echo e($products->quantity); ?></td>
            <td> <?php echo e($products->unit); ?></td>
            <td> <?php echo e($products->description); ?></td>
            <?php if($products->approved == 0): ?>
            <td class="td-actions text-right">
                <a href="<?php echo e(route('storeedit-varient',$products->varient_id)); ?>" rel="tooltip" class="btn btn-success">
                    <i class="fa fa-edit"></i>
                </a>
                <a href="<?php echo e(route('storedelete-varient',$products->varient_id)); ?>" onClick="return confirm('Are you sure you want to permanently remove this Product Varient.')" rel="tooltip" class="btn btn-danger">
                    <i class="fa fa-trash"></i>
                </a>
            </td>
            <?php else: ?>
            <td class="td-actions text-right">
            <p><b style="color:red"> Approved by Admin</b></p>
          </td>
            <?php endif; ?>
        </tr>
          <?php $i++; ?>
                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  <?php else: ?>
                    <tr>
                      <td><?php echo e(__('keywords.No data found')); ?></td>
                    </tr>
                  <?php endif; ?>
    </tbody>
</table>
</div>
</div>
</div>
</div>
</div>
<div>
    </div>
    <?php $__env->stopSection(); ?>
</div>
<?php echo $__env->make('store.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/softgentech/projectfiles.softgentech.com/projectfiles/source/resources/views/store/store_product/varient/show_varient.blade.php ENDPATH**/ ?>