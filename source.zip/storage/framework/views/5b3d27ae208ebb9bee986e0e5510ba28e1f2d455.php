
<style>
   
    .material-icons{
        margin-top:0px !important;
        margin-bottom:0px !important;
    }
</style>
<?php $__env->startSection('content'); ?>
<div class="container-fluid">
 <div class="row">
<div class="col-lg-12">
    <?php if(session()->has('success')): ?>
   <div class="alert alert-success">
    <?php if(is_array(session()->get('success'))): ?>
            <ul>
                <?php $__currentLoopData = session()->get('success'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($message); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
            <?php else: ?>
                <?php echo e(session()->get('success')); ?>

            <?php endif; ?>
        </div>
    <?php endif; ?>
     <?php if(count($errors) > 0): ?>
      <?php if($errors->any()): ?>
        <div class="alert alert-danger" role="alert">
          <?php echo e($errors->first()); ?>

          <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">×</span>
          </button>
        </div>
      <?php endif; ?>
    <?php endif; ?>
    </div>
<div class="col-lg-12">
   
<div class="card">    
<div class="card-header card-header-primary">
      <h4 class="card-title "><?php echo e(__('keywords.Delivery Boy')); ?> <?php echo e(__('keywords.Callback Requests')); ?></h4>
    </div>
<div class="container"> <br> 
<table id="datatableDefault" class="table text-nowrap w-100">
    <thead class="thead-light">
        <tr>
            <th>#</th>
            <th><?php echo e(__('keywords.ID')); ?></th>
            <th><?php echo e(__('keywords.Delivery Boy')); ?> <?php echo e(__('keywords.Name')); ?></th>
            <th><?php echo e(__('keywords.Delivery Boy')); ?> <?php echo e(__('keywords.Phone')); ?></th>
            <th class="text-center"><?php echo e(__('keywords.Actions')); ?></th>
        </tr>
    </thead>
    <tbody>
           <?php if(count($requests)>0): ?>
          <?php $i=1; ?>
          <?php $__currentLoopData = $requests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $request): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td class="text-center"><?php echo e($i); ?></td>
            <td><?php echo e($request->driver_id); ?></td>
            <td><?php echo e($request->driver_name); ?></td>
            <td><?php echo e($request->driver_phone); ?></td>
            <td class="td-actions text-center">
                <?php if($request->processed == 0): ?>
                <a href="<?php echo e(route('driver_callbackproc',$request->callback_req_id)); ?>" rel="tooltip" class="btn btn-success">
                    <i class="fa fa-phone"></i> &nbsp; <?php echo e(__('keywords.Process')); ?>

                </a>
                <?php else: ?>
                <span style="color:green; font-weight:bold"><?php echo e(__('keywords.Processed')); ?></span>
                <?php endif; ?>
            </td>
        </tr>
          <?php $i++; ?>
                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  <?php else: ?>
                    <tr>
                      <td><?php echo e(__('keywords.No data found')); ?></td>
                    </tr>
                  <?php endif; ?>
    </tbody>
</table>
</div>  
</div>
</div>
</div>
</div>
<div>
    </div>

    <?php $__env->stopSection(); ?>
</div>
<?php echo $__env->make('store.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\projectfiles\source\resources\views/store/callback/driver_request.blade.php ENDPATH**/ ?>