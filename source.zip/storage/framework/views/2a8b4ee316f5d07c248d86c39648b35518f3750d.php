<?php $__env->startSection('content'); ?>
<div class="container-fluid">
          <div class="row">
              <div class="col-lg-12">
                <?php if(session()->has('success')): ?>
               <div class="alert alert-success">
                <?php if(is_array(session()->get('success'))): ?>
                        <ul>
                            <?php $__currentLoopData = session()->get('success'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($message); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                        <?php else: ?>
                            <?php echo e(session()->get('success')); ?>

                        <?php endif; ?>
                    </div>
                <?php endif; ?>
                 <?php if(count($errors) > 0): ?>
                  <?php if($errors->any()): ?>
                    <div class="alert alert-danger" role="alert">
                      <?php echo e($errors->first()); ?>

                      <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">×</span>
                      </button>
                    </div>
                  <?php endif; ?>
                <?php endif; ?>
                </div>
            <div class="col-md-12">
              <div class="card">
                <div class="card-header card-header-primary">
                  <h4 class="card-title"><?php echo e(__('keywords.Edit')); ?> <?php echo e(__('keywords.Store')); ?> <?php echo e(__('keywords.Banner')); ?></h4>
                  
                </div>
                <div class="card-body">
                  <form class="forms-sample" action="<?php echo e(route('storebannerupdate',$city->banner_id)); ?>" method="post" enctype="multipart/form-data">
                      <?php echo e(csrf_field()); ?>


                    <div class="row">
                      <div class="col-md-12">
                        <div class="form-group">
                          <label class="bmd-label-floating"><?php echo e(__('keywords.Title')); ?></label>
                          
                          <input type="text" name="banner" value="<?php echo e($city->banner_name); ?>" class="form-control">
                        </div>
                        
                        
                         <img src="<?php echo e($url_aws.$city->banner_image); ?>" alt="image" name="old_banner" style="width:100px;height:100px; border-radius:50%">
                     <div class="row">
                      <div class="col-md-12">
                        <div class="form">
                          <label class="bmd-label-floating"><?php echo e(__('keywords.Image')); ?></label>
                          <input type="hidden" name="old_image" value="<?php echo e($city->banner_image); ?>" >
                          <input type="file"name="image" class="form-control">
                          
                        </div>
                      </div>

                    </div>
                    </div>
                     <div class="col-md-12">    
                      <div class="form-group">
                          <label class="bmd-label-floating"><?php echo e(__('keywords.Select')); ?> <?php echo e(__('keywords.Category')); ?></label>
                          <select name="cat_id" class="form-control">
                              <option disabled selected><?php echo e(__('keywords.Select')); ?> <?php echo e(__('keywords.Category')); ?></option>
                              <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categorys): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        		          	<option value="<?php echo e($categorys->cat_id); ?>" <?php if($categorys->cat_id == $city->cat_id): ?>selected <?php endif; ?>><?php echo e($categorys->title); ?></option>
        		              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                              
                          </select>
                        </div>
                        </div>
                              <br>
                    

                    <button type="submit" class="btn btn-primary pull-center"><?php echo e(__('keywords.Update')); ?></button>
                    <div class="clearfix"></div>
                  </form>
                </div>
              </div>
            </div>
			</div>
          </div>
<?php $__env->stopSection(); ?>          
<?php echo $__env->make('store.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u518557422/domains/themeatzheaven.online/public_html/source/resources/views/store/banner/banneredit.blade.php ENDPATH**/ ?>