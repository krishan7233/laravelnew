<?php $__env->startSection('content'); ?>
<div class="row">

<div class="container-fluid">
          <div class="row">
            <div class="col-lg-12">
            <?php if(session()->has('success')): ?>
           <div class="alert alert-success">
            <?php if(is_array(session()->get('success'))): ?>
                    <ul>
                        <?php $__currentLoopData = session()->get('success'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($message); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                    <?php else: ?>
                        <?php echo e(session()->get('success')); ?>

                    <?php endif; ?>
                </div>
            <?php endif; ?>
             <?php if(count($errors) > 0): ?>
              <?php if($errors->any()): ?>
                <div class="alert alert-danger" role="alert">
                  <?php echo e($errors->first()); ?>

                  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">×</span>
                  </button>
                </div>
              <?php endif; ?>
            <?php endif; ?>
            </div>  
            <div class="col-md-12">
              <div class="card">
                <div class="card-header card-header-primary">
                  <h4 class="card-title"><?php echo e(__('keywords.Send Payout Request')); ?></h4>
                  
                   
                </div>
                <div class="card-body">
				
		
					
                <?php if($current < $end): ?>
                 <h5 class="alert-primary" style="color:red" align="center"><?php echo e(__('keywords.Your payout request sent successfully')); ?>.</h5><p class="alert-primary" style="color:black" align="center"><?php echo e(__('keywords.You can raise next request on')); ?> <?php echo e($end); ?>.</p>
                 <?php else: ?>
                <?php if($sumprice - $paid >= $min_amt): ?>    
                  <form class="forms-sample" action="<?php echo e(route('payout_req_sent')); ?>" method="post" enctype="multipart/form-data">
                      <?php echo e(csrf_field()); ?>

                      
                     <?php if($bank): ?> 
                    <div class="row">
                      <div class="col-md-4">
                        <div class="form-group">
                          <label><?php echo e(__('keywords.Bank Name')); ?></label>
                          <input type="text" name="bank_name" value="<?php echo e($bank->bank_name); ?>" class="form-control">
                        </div>
                      </div>
                      <div class="col-md-4">
                        <div class="form-group">
                          <label><?php echo e(__('keywords.Account Number')); ?></label>
                          <input type="number" name="ac_no" value="<?php echo e($bank->ac_no); ?>" class="form-control">
                        </div>
                      </div>
                      
                       
                     <div class="col-md-4">
                        <div class="form-group">
                          <label><?php echo e(__('keywords.IFSC Code')); ?></label>
                          <input type="text" name="ifsc" value="<?php echo e($bank->ifsc); ?>" class="form-control">
                        </div>
                      </div>
                      
                      
                    </div>
                    
                    <div class="row">
                      <div class="col-md-4">
                        <div class="form-group">
                          <label><?php echo e(__('keywords.Account Holder Name')); ?></label>
                          <input type="text" name="holder_name" value="<?php echo e($bank->holder_name); ?>" class="form-control">
                        </div>
                      </div>
                      <div class="col-md-4">
                        <div class="form-group">
                            <label><?php echo e(__('keywords.UPI')); ?></label></label>
                          <input type="text" name="upi" value="<?php echo e($bank->upi); ?>" class="form-control">
                        </div>
                      </div>
                       <div class="col-md-4">
                        <div class="form-group">
                            <label>Payout Amount(<?php echo e($currency->currency_sign); ?>)</label>
                            <input type="number" name="payout_amt"  class="form-control" value="<?php echo e($total_earnings->sumprice); ?>" min="<?php echo e($min_amt); ?>" step=".01" <?php if($total_earnings->paid != NULL): ?>
                                max="<?php echo e($total_earnings->sumprice - $total_earnings->paid); ?>"
                                <?php else: ?>
                                max="<?php echo e($total_earnings->sumprice); ?>"
                                <?php endif; ?>/>
                        </div>
                    </div><br>
                    <button type="submit" class="btn btn-primary pull-center"><?php echo e(__('keywords.Submit')); ?></button>
                    <div class="clearfix"></div>
                  
                </div>
              </div>
            </div>
			</div>
          </div>
          <?php else: ?>
           <div class="row">
                      <div class="col-md-4">
                        <div class="form-group">
                          <label class="bmd-label-floating"><?php echo e(__('keywords.Bank Name')); ?></label>
                          <input type="text" name="bank_name" class="form-control">
                        </div>
                      </div>
                      <div class="col-md-4">
                        <div class="form-group">
                          <label class="bmd-label-floating"><?php echo e(__('keywords.Account Number')); ?></label>
                          <input type="number" name="ac_no" class="form-control">
                        </div>
                      </div>
                      
                       
                     <div class="col-md-4">
                        <div class="form-group">
                          <label class="bmd-label-floating"><?php echo e(__('keywords.IFSC Code')); ?></label>
                          <input type="text" name="ifsc" class="form-control">
                        </div>
                      </div>
                      
                      
                    </div>
                    
                    <div class="row">
                      <div class="col-md-4">
                        <div class="form-group">
                          <label class="bmd-label-floating"><?php echo e(__('keywords.Account Holder Name')); ?></label>
                          <input type="text" name="holder_name" class="form-control">
                        </div>
                      </div>
                      <div class="col-md-4">
                        <div class="form-group">
                            <label class="bmd-label-floating"><?php echo e(__('keywords.UPI')); ?></label></label>
                          <input type="text" name="upi" class="form-control">
                        </div>
                      </div>
                         <div class="col-md-4">
                        <div class="form-group">
                            <label>Payout Amount(<?php echo e($currency->currency_sign); ?>)</label>
                           <input type="number" name="payout_amt" value="<?php echo e($total_earnings->sumprice - $total_earnings->paid); ?>" min="<?php echo e($min_amt); ?>" class="form-control" step=".01" <?php if($total_earnings->paid != NULL): ?>
                                max="<?php echo e($total_earnings->sumprice - $total_earnings->paid); ?>"
                                <?php else: ?>
                                max="<?php echo e($total_earnings->sumprice); ?>"
                                <?php endif; ?>/>
                        </div>
                    </div>
                    </div><br>
                    <button type="submit" class="btn btn-primary pull-center"><?php echo e(__('keywords.Submit')); ?></button>
                    <div class="clearfix"></div>
                  
                </div>
              </div>
            </div>
			</div>
          </div>
          <?php endif; ?>
          </form>
          <?php else: ?>
          <h5 class="alert-danger" style="color:red" align="center"><?php echo e(__('keywords.You cannot request for payout because your earning is less than')); ?> <?php echo e($currency->currency_sign); ?> <?php echo e($min_amt); ?></h5>
          <?php endif; ?>
           <?php endif; ?>        
        
<?php $__env->stopSection(); ?> 


<?php echo $__env->make('store.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u518557422/domains/themeatzheaven.online/public_html/source/resources/views/store/payout_req.blade.php ENDPATH**/ ?>