   <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.0.0/jquery.min.js"></script>
<?php $__env->startSection('content'); ?>
 <div class="container-fluid">
          <div class="row">
             <div class="col-lg-12">
                <?php if(session()->has('success')): ?>
               <div class="alert alert-success">
                <?php if(is_array(session()->get('success'))): ?>
                        <ul>
                            <?php $__currentLoopData = session()->get('success'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($message); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                        <?php else: ?>
                            <?php echo e(session()->get('success')); ?>

                        <?php endif; ?>
                    </div>
                <?php endif; ?>
                 <?php if(count($errors) > 0): ?>
                  <?php if($errors->any()): ?>
                    <div class="alert alert-danger" role="alert">
                      <?php echo e($errors->first()); ?>

                      <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">×</span>
                      </button>
                    </div>
                  <?php endif; ?>
                <?php endif; ?>
           </div> 
            <div class="col-md-12">
              <div class="card">
                <div class="card-header card-header-primary">
                  <h4 class="card-title"><?php echo e(__('keywords.Edit')); ?> <?php echo e(__('keywords.User')); ?></h4>
                  <form class="forms-sample" action="<?php echo e(route('up_user', $user->id)); ?>" method="post" enctype="multipart/form-data">
                      <?php echo e(csrf_field()); ?>

                </div>
                <div class="card-body">

                    <div class="row">
                      <div class="col-md-6">
                        <div class="form-group">
                          <label class="bmd-label-floating"><?php echo e(__('keywords.City')); ?></label>
                     
                            <select id="select1"  class="form-control" name="city">
                            <?php $__currentLoopData = $city; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>    
                              <option value="<?php echo e($c->city_id); ?>" <?php if($user->user_city == $c->city_id): ?> selected <?php endif; ?>><?php echo e($c->city_name); ?></option>
                             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                            </select>
                            


                        </div>
                      </div>
                       <div class="col-md-6">
                        <div class="form-group">
                          <label class="bmd-label-floating"><?php echo e(__('keywords.Society')); ?></label>
                        <select id="select2" class="form-control" name="society">
                           <?php $__currentLoopData = $society; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>    
                              <option value="<?php echo e($sc->society_id); ?>" city="<?php echo e($sc->city_id); ?>" <?php if($user->user_area == $sc->society_id): ?> selected <?php endif; ?>><?php echo e($sc->society_name); ?></option>
                             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                        </select>
                        </div>
                      </div>
                      
                    </div>

                     <div class="row">
                      <div class="col-md-6">
                        <div class="form-group">
                          <label class="bmd-label-floating"><?php echo e(__('keywords.User Name')); ?></label>
                          <input type="text" value="<?php echo e($user->name); ?>" name="name" class="form-control">
                        </div>
                      </div>
                      <div class="col-md-6">
                        <div class="form-group">
                          <label class="bmd-label-floating"><?php echo e(__('keywords.User Email')); ?></label>
                          <input type="text" value="<?php echo e($user->email); ?>" name="email" class="form-control">
                        </div>
                      </div>

                    </div>
                    <div class="row">
                      <div class="col-md-6">
                        <div class="form-group">
                          <label class="bmd-label-floating"><?php echo e(__('keywords.User phone')); ?></label>
                          <input type="text" value="<?php echo e($user->user_phone); ?>" name="phone" class="form-control">
                        </div>
                      </div>
                      <div class="col-md-6">
                        <div class="form-group">
                          <label class="bmd-label-floating"><?php echo e(__('keywords.User Password')); ?></label>
                          <input type="password" placeholder="Enter New Password If you want to change" name="password" class="form-control">
                        </div>
                      </div>

                    </div>
                   
                      <div class="row">
                       <div class="col-md-6">
                        <div class="form-group">
                          <label class="bmd-label-floating"><?php echo e(__('keywords.Wallet Balance')); ?></label>
                          <input type="text" value="<?php echo e($user->wallet); ?>" name="wallet" class="form-control">
                        </div>
                      </div>
                      <div class="col-md-6">
                        <div class="form-group">
                          <label class="bmd-label-floating"><?php echo e(__('keywords.User Rewards')); ?></label>
                          <input type="number" value="<?php echo e($user->rewards); ?>" name="reward" class="form-control">
                        </div>
                      </div>
                    </div><br>
                    <button type="submit" class="btn btn-primary pull-center"><?php echo e(__('keywords.Submit')); ?></button>
                    <a href="<?php echo e(route('subcatlist')); ?>" class="btn"><?php echo e(__('keywords.Close')); ?></a>
                    <div class="clearfix"></div>
                  </form>
                </div>
              </div>
            </div>
			</div>
          </div>
          <script>
              $("#select1").change(function() {
  if ($(this).data('options') === undefined) {
    /*Taking an array of all options-2 and kind of embedding it on the select1*/
    $(this).data('options', $('#select2 option').clone());
  }
  var id = $(this).val();
  var options = $(this).data('options').filter('[city=' + id + ']');
  $('#select2').html(options);
});
          </script>
<?php $__env->stopSection(); ?>





<?php echo $__env->make('admin.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\projectfiles\source\resources\views/admin/user/edit.blade.php ENDPATH**/ ?>