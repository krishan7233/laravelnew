<html>
    <body>
        <p>Out For Delivery: Your order id #{{$cart_id}} contains of {{$prod_name}} of price rs {{$price2}} is Out For Delivery.Get ready.</p>
    </body>
</html>