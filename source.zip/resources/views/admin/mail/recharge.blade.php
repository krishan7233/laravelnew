<html>
    <body>
        <p>
        Welcome Dear, {{$user_name}} to {{$app_name}} Family. We are happy to have you here."
        </p>
    </body>
</html>